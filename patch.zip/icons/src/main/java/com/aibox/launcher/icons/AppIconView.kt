package com.aibox.launcher.icons

import android.content.Context
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.core.graphics.drawable.toBitmap
import com.aibox.launcher.core.model.InstalledApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal object AppIconCache {
    private val cache = LruCache<String, ImageBitmap>(256)
    fun get(packageName: String): ImageBitmap? = cache.get(packageName)
    fun put(packageName: String, icon: ImageBitmap) {
        cache.put(packageName, icon)
    }
    fun remove(packageName: String) {
        cache.remove(packageName)
    }
}

private fun loadIcon(context: Context, packageName: String): ImageBitmap? {
    // сначала — своя иконка, выбранная пользователем
    val custom = CustomIconStore.file(context, packageName)
    if (custom.exists()) {
        val bitmap = runCatching { BitmapFactory.decodeFile(custom.path)?.asImageBitmap() }.getOrNull()
        if (bitmap != null) {
            AppIconCache.put(packageName, bitmap)
            return bitmap
        }
    }
    return runCatching {
        context.packageManager.getApplicationIcon(packageName)
            .toBitmap(width = 160, height = 160).asImageBitmap()
    }.getOrNull()?.also { AppIconCache.put(packageName, it) }
}

/** Загружает иконку приложения в фоне и кэширует её. */
@Composable
fun rememberAppIcon(packageName: String): ImageBitmap? {
    val context = LocalContext.current
    val version = CustomIconStore.version
    val state = produceState<ImageBitmap?>(
        initialValue = AppIconCache.get(packageName),
        key1 = packageName,
        key2 = version
    ) {
        val cached = AppIconCache.get(packageName)
        value = cached ?: withContext(Dispatchers.IO) { loadIcon(context, packageName) }
    }
    return state.value
}

/**
 * Превью иконки: встроенная иконка лаунчера рисуется вектором,
 * пользовательская или системная — растром.
 */
@Composable
fun AppIconPreview(
    packageName: String,
    label: String,
    size: Dp,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    // version обязателен: по нему превью обновляется сразу после назначения иконки.
    val version = CustomIconStore.version
    val builtin = remember(version, packageName) {
        CustomIconStore.builtinKey(context, packageName)?.let { BuiltinIcons.byKey(it) }
    }
    val bitmap = rememberAppIcon(packageName)
    val shape = RoundedCornerShape(size * 0.22f)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.10f))
    ) {
        when {
            builtin != null -> Icon(
                imageVector = builtin.vector,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(size * 0.62f)
            )
            bitmap != null -> Image(
                bitmap = bitmap,
                contentDescription = label,
                modifier = Modifier.size(size)
            )
        }
    }
}

/** Иконка приложения со скруглением и подписью. */
@Composable
fun AppIconView(
    app: InstalledApp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 64.dp,
    showLabel: Boolean = true,
    labelColor: Color = Color.White,
    labelSize: TextUnit = 12.sp
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIconPreview(app.packageName, app.label, iconSize)
        if (showLabel) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = app.label,
                color = labelColor,
                fontSize = labelSize,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(iconSize + 16.dp)
            )
        }
    }
}
