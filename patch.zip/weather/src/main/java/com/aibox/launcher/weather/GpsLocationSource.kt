package com.aibox.launcher.weather

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * GPS без Google Play Services: системный LocationManager.
 * Данные приходят только после разрешения ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION,
 * которое запрашивается из лаунчера при включении режима «по GPS».
 */
class GpsLocationSource(context: Context) {

    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var callback: ((Location) -> Unit)? = null
    private var registered = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            callback?.invoke(location)
        }

        override fun onProviderDisabled(provider: String) = Unit
        override fun onProviderEnabled(provider: String) = Unit
    }

    fun hasPermission(): Boolean =
        appContext.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            appContext.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun currentLocation(): Location? {
        if (!hasPermission()) return null
        return providers()
            .mapNotNull { provider ->
                runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
            }
            .maxByOrNull { it.time }
    }

    /** Подписываемся на обновления не чаще раза в минуту и не точнее 50 метров. */
    fun startUpdates(onLocation: (Location) -> Unit): Boolean {
        if (!hasPermission()) return false
        callback = onLocation
        var started = false
        providers().forEach { provider ->
            val ok = runCatching {
                manager.requestLocationUpdates(
                    provider,
                    60_000L,
                    50f,
                    listener,
                    Looper.getMainLooper()
                )
            }.isSuccess
            if (ok) started = true
        }
        registered = started
        if (!started) callback = null
        return started
    }

    fun stopUpdates() {
        if (registered) {
            runCatching { manager.removeUpdates(listener) }
            registered = false
        }
        callback = null
    }

    /**
     * Человекочитаемое имя места для виджетов и строки состояния погоды.
     * Геокодирование выполняется в IO-потоке, чтобы не блокировать UI;
     * при отсутствии ответа возвращаем координаты.
     */
    suspend fun describe(location: Location): String = withContext(Dispatchers.IO) {
        val geocoder = Geocoder(appContext, Locale("ru"))
        val place = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val result = AtomicReference<Address?>(null)
            val done = CountDownLatch(1)
            runCatching {
                geocoder.getFromLocation(
                    location.latitude,
                    location.longitude,
                    1,
                    object : Geocoder.GeocodeListener {
                        override fun onGeocode(addresses: MutableList<Address>) {
                            result.set(addresses.firstOrNull())
                            done.countDown()
                        }

                        override fun onError(errorMessage: String?) {
                            done.countDown()
                        }
                    }
                )
            }.onFailure { done.countDown() }
            if (done.await(GEOCODE_TIMEOUT_MS, TimeUnit.MILLISECONDS)) result.get() else null
        } else {
            @Suppress("DEPRECATION")
            runCatching {
                geocoder.getFromLocation(location.latitude, location.longitude, 1)
            }.getOrNull()?.firstOrNull()
        }

        return@withContext place?.locality
            ?: place?.subAdminArea
            ?: place?.adminArea
            ?: String.format(Locale.getDefault(), "%.3f, %.3f", location.latitude, location.longitude)
    }

    private companion object {
        const val GEOCODE_TIMEOUT_MS = 3_000L
    }

    private fun providers(): List<String> = listOf(
        LocationManager.NETWORK_PROVIDER,
        LocationManager.GPS_PROVIDER
    ).filter { provider ->
        runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false)
    }
}
