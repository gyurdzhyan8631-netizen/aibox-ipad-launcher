package com.aibox.launcher.widgets

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aibox.launcher.core.ui.theme.LocalLauncherTokens
import org.json.JSONObject
import java.util.Locale

/**
 * Пять встроенных виджетов рисуются прямо Compose, без системного AppWidget.
 * Так они гарантированно появляются на столе: Android не требует диалога
 * привязки, а содержимое never не бывает пустым.
 *
 * Идентификатор такого виджета — отрицательный appWidgetId (-1..-5).
 */
enum class BuiltinWidgetKey(val id: Int, val title: String, val symbol: String) {
    WEATHER(-1, "Погода", "☀"),
    NAVIGATOR(-2, "Навигатор", "➤"),
    YOUTUBE(-3, "YouTube", "▶"),
    MUSIC(-4, "Музыка", "♫"),
    MEMORY(-5, "Память", "▣");

    companion object {
        fun fromId(id: Int): BuiltinWidgetKey? = entries.firstOrNull { it.id == id }
    }
}

private val CARD_BG = Color(0xE60C1424)
private val TEXT = Color(0xFFFFFFFF)
private val MUTED = Color(0xFFB9C8E0)
private val ACCENT = Color(0xFF0381FE)

@Composable
fun BuiltinWidgetCard(key: BuiltinWidgetKey, modifier: Modifier = Modifier) {
    val tokens = LocalLauncherTokens.current
    val accent = runCatching { tokens.accent }.getOrDefault(ACCENT)
    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(20.dp))
            .background(CARD_BG)
            .padding(14.dp)
    ) {
        when (key) {
            BuiltinWidgetKey.WEATHER -> WeatherBody(accent)
            BuiltinWidgetKey.NAVIGATOR -> NavigatorBody(accent)
            BuiltinWidgetKey.YOUTUBE -> YoutubeBody(accent)
            BuiltinWidgetKey.MUSIC -> MusicBody(accent)
            BuiltinWidgetKey.MEMORY -> MemoryBody(accent)
        }
    }
}

@Composable
private fun CardTitle(text: String, symbol: String, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(26.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(accent.copy(alpha = 0.35f))
        ) {
            Text(symbol, color = Color.White, fontSize = 14.sp)
        }
        Spacer(Modifier.size(8.dp))
        Text(text, color = MUTED, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BigText(text: String, size: Int = 24) {
    Text(
        text,
        color = TEXT,
        fontSize = size.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Start
    )
}

@Composable
private fun ActionButton(text: String, accent: Color, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(accent)
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp)
    ) {
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun WeatherBody(accent: Color) {
    val context = LocalContext.current
    val snapshot = runCatching {
        val raw = context.getSharedPreferences("weather_cache", Context.MODE_PRIVATE)
            .getString("snapshot", null)
        if (raw.isNullOrBlank()) null else JSONObject(raw)
    }.getOrNull()
    val temp = snapshot?.optInt("tempC") ?: 0
    val condition = snapshot?.optString("condition", "") ?: ""
    val city = snapshot?.optString("cityName", "") ?: ""
    val icon = when (condition) {
        "CLEAR" -> "☀"
        "CLOUDY", "OVERCAST", "FOG", "WIND" -> "☁"
        "RAIN", "HEAVY_RAIN", "THUNDERSTORM" -> "☂"
        "SNOW" -> "❄"
        else -> "◌"
    }
    val text = when (condition) {
        "CLEAR" -> "Ясно"
        "CLOUDY" -> "Облачно"
        "OVERCAST" -> "Пасмурно"
        "RAIN" -> "Дождь"
        "HEAVY_RAIN" -> "Сильный дождь"
        "SNOW" -> "Снег"
        "THUNDERSTORM" -> "Гроза"
        "FOG" -> "Туман"
        "WIND" -> "Ветрено"
        else -> "Погода"
    }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        CardTitle("Погода", "☀", accent)
        Column {
            BigText("$icon ${if (snapshot == null) "—" else "${if (temp > 0) "+" else ""}$temp°"}", 30)
            Text(text, color = MUTED, fontSize = 12.sp)
            Text(city.ifBlank { "Укажите город в настройках" }, color = MUTED, fontSize = 11.sp)
        }
        ActionButton("Открыть погоду →", accent) {
            launchPreferred(context, "weather_package", Intent(Intent.ACTION_VIEW, Uri.parse("https://weather.google.com")))
        }
    }
}

@Composable
private fun NavigatorBody(accent: Color) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        CardTitle("Навигатор", "➤", accent)
        Column {
            BigText("Куда едем?")
            Text("Yandex Navi / Карты", color = MUTED, fontSize = 12.sp)
        }
        ActionButton("Построить маршрут", accent) {
            launchPreferred(context, "nav_package", Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))
        }
    }
}

@Composable
private fun YoutubeBody(accent: Color) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        CardTitle("YouTube", "▶", accent)
        BigText("Смотреть видео", 20)
        ActionButton("Открыть YouTube →", accent) {
            val app = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
            safeStart(context, app ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
        }
    }
}

@Composable
private fun MusicBody(accent: Color) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        CardTitle("Музыка", "♫", accent)
        BigText("Управление", 20)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "⏮" to KeyEvent.KEYCODE_MEDIA_PREVIOUS,
                "▶" to KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                "⏭" to KeyEvent.KEYCODE_MEDIA_NEXT
            ).forEach { (label, code) ->
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(accent.copy(alpha = 0.4f))
                        .clickable { dispatchMedia(context, code) }
                ) { Text(label, color = Color.White, fontSize = 16.sp) }
            }
        }
        ActionButton("Открыть плеер →", accent) {
            launchPreferred(context, "music_package", Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC))
        }
    }
}

@Composable
private fun MemoryBody(accent: Color) {
    val context = LocalContext.current
    val stat = runCatching { StatFs(Environment.getDataDirectory().path) }.getOrNull()
    val total = (stat?.blockCountLong ?: 1L) * (stat?.blockSizeLong ?: 1L)
    val free = (stat?.availableBlocksLong ?: 0L) * (stat?.blockSizeLong ?: 1L)
    val used = (((total - free) * 100) / total.coerceAtLeast(1L)).toInt().coerceIn(0, 100)
    fun gb(bytes: Long) = String.format(Locale("ru"), "%.1f ГБ", bytes / (1024f * 1024f * 1024f))
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        CardTitle("Память", "▣", accent)
        Column {
            BigText("${gb(free)} свободно", 18)
            Text("из ${gb(total)}", color = MUTED, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { used / 100f },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = accent,
                trackColor = Color(0x33FFFFFF)
            )
        }
        ActionButton("Открыть хранилище →", accent) {
            safeStart(context, Intent(android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
        }
    }
}

private fun launchPreferred(context: Context, prefKey: String, fallback: Intent) {
    val packageName = context.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)
        .getString(prefKey, "") ?: ""
    val chosen = if (packageName.isBlank()) null else context.packageManager.getLaunchIntentForPackage(packageName)
    safeStart(context, chosen ?: fallback)
}

private fun safeStart(context: Context, intent: Intent) {
    runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private fun dispatchMedia(context: Context, code: Int) {
    runCatching {
        val audio = context.getSystemService(AudioManager::class.java) ?: return
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
