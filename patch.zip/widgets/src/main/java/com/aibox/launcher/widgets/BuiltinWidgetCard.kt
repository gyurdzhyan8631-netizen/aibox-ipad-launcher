package com.aibox.launcher.widgets

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aibox.launcher.core.ui.glassSurface
import com.aibox.launcher.core.ui.theme.LocalLauncherTokens
import org.json.JSONObject
import java.util.Locale

/**
 * Шесть встроенных табло рисуются прямо Compose, без системного AppWidget.
 * Компактная версия: помещается в две строки сетки 6×4 и не требует диалога привязки.
 * Идентификатор — отрицательный appWidgetId (-1..-6).
 */
enum class BuiltinWidgetKey(val id: Int, val title: String, val symbol: String) {
    WEATHER(-1, "Погода", "☀"),
    NAVIGATOR(-2, "Навигатор", "➤"),
    MAPS(-3, "Карты", "◎"),
    YOUTUBE(-4, "YouTube", "▶"),
    MUSIC(-5, "Музыка", "♫"),
    MEMORY(-6, "Память", "▣");

    companion object {
        fun fromId(id: Int): BuiltinWidgetKey? = entries.firstOrNull { it.id == id }
    }
}

private val CARD_BG = Color(0xD908111D)
private val TEXT = Color(0xFFFFFFFF)
private val MUTED = Color(0xFFD3DEF0)
private val ACCENT = Color(0xFF0381FE)

@Composable
fun BuiltinWidgetCard(key: BuiltinWidgetKey, modifier: Modifier = Modifier) {
    val tokens = LocalLauncherTokens.current
    val accent = runCatching { tokens.accent }.getOrDefault(ACCENT)
    val context = LocalContext.current
    val click: () -> Unit = when (key) {
        BuiltinWidgetKey.WEATHER -> {
            { launchPreferred(context, "weather_package", Intent(Intent.ACTION_VIEW, Uri.parse("https://weather.google.com"))) }
        }
        BuiltinWidgetKey.NAVIGATOR -> {
            { launchPreferred(context, "nav_package", Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))) }
        }
        BuiltinWidgetKey.MAPS -> {
            {
                val app = context.packageManager.getLaunchIntentForPackage("com.google.android.apps.maps")
                safeStart(context, app ?: Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))
            }
        }
        BuiltinWidgetKey.YOUTUBE -> {
            {
                val app = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                safeStart(context, app ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
            }
        }
        BuiltinWidgetKey.MUSIC -> {
            { launchPreferred(context, "music_package", Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)) }
        }
        BuiltinWidgetKey.MEMORY -> {
            { safeStart(context, Intent(android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
        }
    }
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(shape)
            .background(CARD_BG, shape)
            .glassSurface(shape, tint = accent, strength = 1.25f)
            .clickable(onClick = click)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            CardTitle(key.title, key.symbol, accent)
            when (key) {
                BuiltinWidgetKey.WEATHER -> WeatherBody()
                BuiltinWidgetKey.NAVIGATOR -> NavigatorBody()
                BuiltinWidgetKey.MAPS -> MapsBody()
                BuiltinWidgetKey.YOUTUBE -> YoutubeBody()
                BuiltinWidgetKey.MUSIC -> MusicBody(accent)
                BuiltinWidgetKey.MEMORY -> MemoryBody(accent)
            }
        }
    }
}

@Composable
private fun CardTitle(text: String, symbol: String, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(accent.copy(alpha = 0.4f))
        ) {
            Text(symbol, color = Color.White, fontSize = 11.sp)
        }
        Spacer(Modifier.size(6.dp))
        Text(text, color = MUTED, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BigText(text: String, size: Int = 18) {
    Text(
        text,
        color = TEXT,
        fontSize = size.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Start,
        maxLines = 1
    )
}

@Composable
private fun WeatherBody() {
    val context = LocalContext.current
    val snapshot = runCatching {
        val raw = context.getSharedPreferences("weather_cache", Context.MODE_PRIVATE)
            .getString("snapshot", null)
        if (raw.isNullOrBlank()) null else JSONObject(raw)
    }.getOrNull()
    val temp = snapshot?.optInt("tempC") ?: 0
    val condition = snapshot?.optString("condition", "") ?: ""
    val city = snapshot?.optString("cityName", "") ?: ""
    val icon = when (condition) {
        "CLEAR" -> "☀"
        "CLOUDY", "OVERCAST", "FOG", "WIND" -> "☁"
        "RAIN", "HEAVY_RAIN", "THUNDERSTORM" -> "☂"
        "SNOW" -> "❄"
        else -> "◌"
    }
    val text = when (condition) {
        "CLEAR" -> "Ясно"
        "CLOUDY" -> "Облачно"
        "OVERCAST" -> "Пасмурно"
        "RAIN" -> "Дождь"
        "HEAVY_RAIN" -> "Сильный дождь"
        "SNOW" -> "Снег"
        "THUNDERSTORM" -> "Гроза"
        "FOG" -> "Туман"
        "WIND" -> "Ветрено"
        else -> "Погода"
    }
    Column {
        BigText("$icon ${if (snapshot == null) "—" else "${if (temp > 0) "+" else ""}$temp°"}", 20)
        Text("$text · ${city.ifBlank { "город в настройках" }}", color = MUTED, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun NavigatorBody() {
    Column {
        BigText("Куда едем?", 17)
        Text("Yandex Navi / Карты →", color = MUTED, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun MapsBody() {
    Column {
        BigText("Карты рядом", 16)
        Text("Открыть Карты →", color = MUTED, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun YoutubeBody() {
    Column {
        BigText("Смотреть видео", 16)
        Text("Открыть YouTube →", color = MUTED, fontSize = 10.sp)
    }
}

@Composable
private fun MusicBody(accent: Color) {
    val context = LocalContext.current
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "⏮" to KeyEvent.KEYCODE_MEDIA_PREVIOUS,
                "▶" to KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                "⏭" to KeyEvent.KEYCODE_MEDIA_NEXT
            ).forEach { (label, code) ->
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.45f))
                        .clickable { dispatchMedia(context, code) }
                ) { Text(label, color = Color.White, fontSize = 14.sp) }
            }
        }
        Text("Открыть плеер →", color = MUTED, fontSize = 10.sp)
    }
}

@Composable
private fun MemoryBody(accent: Color) {
    val stat = runCatching { StatFs(Environment.getDataDirectory().path) }.getOrNull()
    val total = (stat?.blockCountLong ?: 1L) * (stat?.blockSizeLong ?: 1L)
    val free = (stat?.availableBlocksLong ?: 0L) * (stat?.blockSizeLong ?: 1L)
    val used = (((total - free) * 100) / total.coerceAtLeast(1L)).toInt().coerceIn(0, 100)
    fun gb(bytes: Long) = String.format(Locale("ru"), "%.1f ГБ", bytes / (1024f * 1024f * 1024f))
    Column {
        BigText("${gb(free)} свободно", 15)
        Text("из ${gb(total)}", color = MUTED, fontSize = 10.sp)
        Spacer(Modifier.height(5.dp))
        LinearProgressIndicator(
            progress = { used / 100f },
            modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
            color = accent,
            trackColor = Color(0x33FFFFFF)
        )
    }
}

private fun launchPreferred(context: Context, prefKey: String, fallback: Intent) {
    val packageName = context.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)
        .getString(prefKey, "") ?: ""
    val chosen = if (packageName.isBlank()) null else context.packageManager.getLaunchIntentForPackage(packageName)
    safeStart(context, chosen ?: fallback)
}

private fun safeStart(context: Context, intent: Intent) {
    runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private fun dispatchMedia(context: Context, code: Int) {
    runCatching {
        val audio = context.getSystemService(AudioManager::class.java) ?: return
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
