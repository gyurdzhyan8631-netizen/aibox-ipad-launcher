package com.aibox.launcher.widgets

/** Сетка рабочего стола: 6 колонок × 4 строки. Ячейки прямоугольные и занимают весь стол. */
const val WIDGET_GRID_COLUMNS = 6
const val WIDGET_GRID_ROWS = 4

/** Размеры виджета в ячейках. Шаги меняют и ширину, и высоту — не только ширину. */
enum class WidgetSizeClass(val id: String, val title: String, val columns: Int, val rows: Int) {
    SMALL("small", "2×2", 2, 2),
    MEDIUM("medium", "3×2", 3, 2),
    LARGE("large", "3×3", 3, 3),
    EXTRA_LARGE("xl", "6×4", 6, 4);

    companion object {
        fun fromId(id: String?): WidgetSizeClass = entries.firstOrNull { it.id == id } ?: MEDIUM
    }
}

/** Одна запись виджета на рабочем столе. */
data class WidgetItem(
    val id: String,
    val appWidgetId: Int,
    val size: WidgetSizeClass,
    val column: Int,
    val row: Int
)

/** Столы начинаются пустыми: встроенные табло добавляет лаунчер при первом запуске. */
fun defaultWidgetBoard(page: Int): List<WidgetItem> = emptyList()

/** Формат одной записи: appWidgetId,sizeId,column,row. */
fun encodeBoard(items: List<WidgetItem>): String = items.joinToString(";") { item ->
    listOf(
        item.appWidgetId.toString(),
        item.size.id,
        item.column.toString(),
        item.row.toString()
    ).joinToString(",")
}

fun parseBoard(raw: String?, fallback: List<WidgetItem>): List<WidgetItem> {
    if (raw.isNullOrBlank()) return fallback
    val parsed = raw.split(';').mapNotNull { entry ->
        val parts = entry.split(',')
        if (parts.size != 4) return@mapNotNull null
        val appWidgetId = parts[0].toIntOrNull() ?: return@mapNotNull null
        val column = parts[2].toIntOrNull() ?: return@mapNotNull null
        val row = parts[3].toIntOrNull() ?: return@mapNotNull null
        // Отрицательные id — встроенные Compose-табло лаунчера (-1..-5).
        if (appWidgetId == 0) return@mapNotNull null
        val size = WidgetSizeClass.fromId(parts[1])
        WidgetItem(
            id = appWidgetId.toString(),
            appWidgetId = appWidgetId,
            size = size,
            column = column.coerceIn(0, (WIDGET_GRID_COLUMNS - size.columns).coerceAtLeast(0)),
            row = row.coerceIn(0, (WIDGET_GRID_ROWS - size.rows).coerceAtLeast(0))
        )
    }
    return parsed.ifEmpty { fallback }
}

/** Первое свободное место для нового виджета. */
fun firstFreeWidgetSpot(items: List<WidgetItem>, size: WidgetSizeClass): Pair<Int, Int> {
    val maxColumn = (WIDGET_GRID_COLUMNS - size.columns).coerceAtLeast(0)
    val maxRow = (WIDGET_GRID_ROWS - size.rows).coerceAtLeast(0)
    for (row in 0..maxRow) {
        for (column in 0..maxColumn) {
            val occupied = items.any { other ->
                column < other.column + other.size.columns &&
                    column + size.columns > other.column &&
                    row < other.row + other.size.rows &&
                    row + size.rows > other.row
            }
            if (!occupied) return column to row
        }
    }
    return 0 to 0
}
