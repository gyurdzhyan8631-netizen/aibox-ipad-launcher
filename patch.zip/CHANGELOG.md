# Changelog

All notable changes to this project will be documented in this file.

## [0.2.0-alpha] - 2026-11-23
### Added
- Рабочие столы 1 и 2: виджеты (Дата, Питание, Сеть) и сетка приложений.
- App Drawer с поиском по приложениям.
- Загрузка списка приложений и кэш иконок (модуль `icons`).
- Кнопка Control Center в шапке теперь открывает шторку.
### Fixed
- Убран дубликат `control-center` и лишняя папка `src` в корне.
- CI сам создаёт и коммитит Gradle Wrapper.

## [0.1.0-alpha] - 2026-11-23
### Added
- Базовая многомодульная структура проекта (16 модулей).
- Система сборки Gradle Kotlin DSL (`build.gradle.kts`, `libs.versions.toml`).
- `AndroidManifest.xml` с поддержкой `HOME` / `DEFAULT` категорий лаунчера и `AccessibilityService`.
- Доменные модели (`DesktopItem`, `DockConfig`, `LauncherThemeStyle`, `WeatherScene`).
- Стартовый каркас интерфейса (Home Screen 1 & 2, Dock Carousel, System Capsule, Control Center, App Drawer, Settings).
- Шаблоны GitHub (Issues, Pull Requests, Release Workflow).
