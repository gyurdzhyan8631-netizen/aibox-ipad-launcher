package com.aibox.launcher.core.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp

/**
 * Стеклянная поверхность: мягкая тень, лёгкий вертикальный блик и светлая кромка.
 * Подложка остаётся достаточно плотной, чтобы белый текст читался на любых обоях.
 */
fun Modifier.glassSurface(
    shape: Shape,
    tint: Color = Color.White,
    strength: Float = 1f
): Modifier = this
    .shadow(
        elevation = 8.dp,
        shape = shape,
        ambientColor = Color(0x66000000),
        spotColor = Color(0x33000000)
    )
    .background(
        brush = Brush.verticalGradient(
            colors = listOf(
                tint.copy(alpha = (0.17f * strength).coerceIn(0f, 0.38f)),
                tint.copy(alpha = (0.06f * strength).coerceIn(0f, 0.20f))
            )
        ),
        shape = shape
    )
    .border(
        width = 1.dp,
        color = tint.copy(alpha = (0.32f * strength).coerceIn(0f, 0.60f)),
        shape = shape
    )

/** Масштабирует всё содержимое (размеры в dp и текст в sp) в [scale] раз. */
@Composable
fun ScaledContent(scale: Float, content: @Composable () -> Unit) {
    val base = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(base.density * scale, base.fontScale)
    ) {
        content()
    }
}
