package com.aibox.launcher.core.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aibox.launcher.core.model.VisualStyle
import com.aibox.launcher.core.model.WidgetStyle

@Immutable
data class LauncherStyleTokens(
    val panelBackground: Color,
    val panelBorder: Color,
    val cardBackground: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val cornerRadius: Dp,
    val isDark: Boolean
)

/** Стиль оформления системных виджетов; задаётся в «Размеры → Стиль виджетов». */
val LocalWidgetStyle = staticCompositionLocalOf { WidgetStyle.IPAD }

val LocalLauncherTokens = staticCompositionLocalOf {
    LauncherStyleTokens(
        panelBackground = Color(0x521C1C1E),
        panelBorder = Color(0x38FFFFFF),
        cardBackground = Color(0x422C2C2E),
        textPrimary = Color.White,
        textSecondary = Color(0xCCFFFFFF),
        accent = Color(0xFF0A84FF),
        cornerRadius = 28.dp,
        isDark = true
    )
}

fun tokensForStyle(style: VisualStyle): LauncherStyleTokens = when (style) {
    VisualStyle.IPADOS_MINIMAL -> LauncherStyleTokens(
        panelBackground = Color(0x541C1C1E),
        panelBorder = Color(0x3DFFFFFF),
        cardBackground = Color(0x452C2C2E),
        textPrimary = Color.White,
        textSecondary = Color(0xCCFFFFFF),
        accent = Color(0xFF0A84FF),
        cornerRadius = 28.dp,
        isDark = true
    )
    VisualStyle.IOS_DARK -> LauncherStyleTokens(
        panelBackground = Color(0xCC0D0D0F),
        panelBorder = Color(0x26FFFFFF),
        cardBackground = Color(0xB818181B),
        textPrimary = Color.White,
        textSecondary = Color(0x99EBEBF5),
        accent = Color(0xFF5E5CE6),
        cornerRadius = 26.dp,
        isDark = true
    )
    VisualStyle.PREMIUM_GLASS -> LauncherStyleTokens(
        panelBackground = Color(0x36FFFFFF),
        panelBorder = Color(0x66FFFFFF),
        cardBackground = Color(0x2EFFFFFF),
        textPrimary = Color.White,
        textSecondary = Color(0xE6FFFFFF),
        accent = Color(0xFF32ADE6),
        cornerRadius = 32.dp,
        isDark = true
    )
    VisualStyle.CLEAN_MINIMAL -> LauncherStyleTokens(
        panelBackground = Color(0xDCF5F5F7),
        panelBorder = Color(0x33000000),
        cardBackground = Color(0xE6FFFFFF),
        textPrimary = Color(0xFF1C1C1E),
        textSecondary = Color(0x993C3C43),
        accent = Color(0xFF007AFF),
        cornerRadius = 24.dp,
        isDark = false
    )
    VisualStyle.AUTOMOTIVE_PREMIUM -> LauncherStyleTokens(
        panelBackground = Color(0xE0111318),
        panelBorder = Color(0x4D38BDF8),
        cardBackground = Color(0xCC1A1E26),
        textPrimary = Color(0xFFF8FAFC),
        textSecondary = Color(0xFFCBD5E1),
        accent = Color(0xFFFF9F0A),
        cornerRadius = 22.dp,
        isDark = true
    )

    // --- обложки брендовых стилей ---
    VisualStyle.IPAD -> LauncherStyleTokens(
        panelBackground = Color(0x661C1C1E),
        panelBorder = Color(0x42FFFFFF),
        cardBackground = Color(0x4A2C2C2E),
        textPrimary = Color.White,
        textSecondary = Color(0xD9FFFFFF),
        accent = Color(0xFF0A84FF),
        cornerRadius = 30.dp,
        isDark = true
    )
    VisualStyle.SAMSUNG_TAB -> LauncherStyleTokens(
        panelBackground = Color(0xD9161D29),
        panelBorder = Color(0x4D3E91FF),
        cardBackground = Color(0xE2232C3B),
        textPrimary = Color(0xFFF5F8FF),
        textSecondary = Color(0xFFB9C8E0),
        accent = Color(0xFF0381FE),
        cornerRadius = 26.dp,
        isDark = true
    )
    VisualStyle.APPLE_DUO -> LauncherStyleTokens(
        panelBackground = Color(0xE6141420),
        panelBorder = Color(0x59BF5AF2),
        cardBackground = Color(0xCC232036),
        textPrimary = Color(0xFFFBF9FF),
        textSecondary = Color(0xFFD6CCEF),
        accent = Color(0xFFBF5AF2),
        cornerRadius = 32.dp,
        isDark = true
    )
    VisualStyle.PIXEL_FOLD -> LauncherStyleTokens(
        panelBackground = Color(0xDCE8F0F5),
        panelBorder = Color(0x33000000),
        cardBackground = Color(0xF2FFFFFF),
        textPrimary = Color(0xFF202124),
        textSecondary = Color(0x995F6368),
        accent = Color(0xFF4285F4),
        cornerRadius = 28.dp,
        isDark = false
    )
}

private val AppleTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 60.sp,
        letterSpacing = (-1.2).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        letterSpacing = (-0.4).sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp
    )
)

@Composable
fun AiBoxLauncherTheme(
    style: VisualStyle = VisualStyle.IPADOS_MINIMAL,
    content: @Composable () -> Unit
) {
    val tokens = tokensForStyle(style)
    val colorScheme = if (tokens.isDark) {
        darkColorScheme(
            primary = tokens.accent,
            background = Color(0xFF0B0F17),
            surface = tokens.panelBackground,
            onPrimary = Color.White,
            onBackground = tokens.textPrimary,
            onSurface = tokens.textPrimary
        )
    } else {
        lightColorScheme(
            primary = tokens.accent,
            background = Color(0xFFE5E5EA),
            surface = tokens.panelBackground,
            onPrimary = Color.White,
            onBackground = tokens.textPrimary,
            onSurface = tokens.textPrimary
        )
    }

    val shapes = Shapes(
        small = RoundedCornerShape(tokens.cornerRadius * 0.5f),
        medium = RoundedCornerShape(tokens.cornerRadius * 0.8f),
        large = RoundedCornerShape(tokens.cornerRadius)
    )

    CompositionLocalProvider(LocalLauncherTokens provides tokens) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppleTypography,
            shapes = shapes,
            content = content
        )
    }
}
