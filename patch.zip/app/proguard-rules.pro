# НЕТ тотального "-keep class com.aibox.launcher.** { *; }":
# это отключало бы R8 для всего лаунчера. Ниже только то, что создаётся по имени
# (Refection/AndroidManifest/AppWidget) или участвует в сериализации.

-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod, RuntimeVisibleAnnotations

# --- Точки входа, создаваемые системой по имени из AndroidManifest.xml ---
-keep class com.aibox.launcher.AiBoxLauncherApp { *; }
-keep class com.aibox.launcher.MainActivity { *; }
-keep class com.aibox.launcher.system.NavAccessibilityService { *; }
-keep class com.aibox.launcher.system.BootReceiver { *; }

# --- AppWidget-провайдеры (ресиверы из манифеста) ---
-keep class com.aibox.launcher.widgets.WeatherWidgetProvider { *; }
-keep class com.aibox.launcher.widgets.NavigatorWidgetProvider { *; }
-keep class com.aibox.launcher.widgets.YouTubeWidgetProvider { *; }
-keep class com.aibox.launcher.widgets.MusicWidgetProvider { *; }
-keep class com.aibox.launcher.widgets.MemoryWidgetProvider { *; }

# --- Compose entrypoint'ы: корневой экран и top-level файлы (@Composable-функции) ---
-keep class com.aibox.launcher.shell.LauncherRootScreen { *; }
-keep class com.aibox.launcher.core.ui.theme.ThemeKt { *; }
-keep class com.aibox.launcher.**Kt { *; }

# --- Модели, используемые как данные лаунчера (в т.ч. через reflection/JSON) ---
-keep class com.aibox.launcher.core.model.** { *; }
-keep class com.aibox.launcher.widgets.WidgetItem { *; }
-keep class com.aibox.launcher.settings.UpdateInfo { *; }
-keep class com.aibox.launcher.weather.WeatherSnapshot { *; }
-keep class com.aibox.launcher.icons.IconPackInfo { *; }
-keep class com.aibox.launcher.icons.PackIconInfo { *; }

# --- Parcelable: CREATOR и getInstance обязательны для Parcel-механизма ---
-keepnames class * implements android.os.Parcelable
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
    public static android.os.Parcelable$Creator getInstance();
}

# --- Serializable: контракт Java-сериализации ---
-keepnames class * implements java.io.Serializable
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}
