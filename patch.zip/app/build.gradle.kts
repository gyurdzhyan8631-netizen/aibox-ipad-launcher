import java.io.File
import java.util.Base64
import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// Версия хранится в version.properties. CI поднимает versionCode через -PciBuild=N,
// но никогда не понижает его относительно значения в файле.
val versionProperties = Properties().apply {
    rootProject.file("version.properties").inputStream().use { load(it) }
}
val baselineVersionCode = versionProperties.getProperty("versionCode")?.trim()?.toIntOrNull()
    ?: error("version.properties: versionCode must be an integer")
val baselineVersionName = versionProperties.getProperty("versionName")?.trim()?.takeIf { it.isNotEmpty() }
    ?: error("version.properties: versionName is missing")

val ciBuild = project.findProperty("ciBuild")?.toString()?.toIntOrNull()
val effectiveVersionCode = if (ciBuild != null && ciBuild > baselineVersionCode) ciBuild else baselineVersionCode
val effectiveVersionName = project.findProperty("versionName")?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    ?: baselineVersionName

android {
    namespace = "com.aibox.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aibox.launcher"
        minSdk = 31
        targetSdk = 35
        versionCode = effectiveVersionCode
        versionName = effectiveVersionName

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField("String", "UPDATE_REPO", "\"gyurdzhyan8631-netizen/aibox-ipad-launcher\"")
        buildConfigField("String", "UPDATE_MANIFEST_NAME", "\"update-manifest.json\"")
    }

    // Постоянный ключ подписи debug-сборок: обновления ставятся поверх без удаления приложения.
    signingConfigs {
        getByName("debug") {
            val keystore = project.file("debug.keystore")
            if (keystore.isFile) {
                storeFile = keystore
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }

        create("release") {
            val envKeystore = System.getenv("AIBOX_RELEASE_KEYSTORE")?.trim()
            val envKeystoreB64 = System.getenv("AIBOX_RELEASE_KEYSTORE_B64")?.trim()
            val envStorePassword = System.getenv("AIBOX_RELEASE_STORE_PASSWORD")
            val envKeyAlias = System.getenv("AIBOX_RELEASE_KEY_ALIAS")
            val envKeyPassword = System.getenv("AIBOX_RELEASE_KEY_PASSWORD")
            val hasCredentials = !envStorePassword.isNullOrBlank()
                && !envKeyAlias.isNullOrBlank()
                && !envKeyPassword.isNullOrBlank()

            // Ключ может быть задан путём к файлу либо base64-строкой (в т.ч. с переводами строк).
            val releaseKeystore: File? = when {
                !envKeystoreB64.isNullOrEmpty() -> runCatching {
                    val bytes = Base64.getMimeDecoder().decode(envKeystoreB64)
                    val outDir = project.layout.buildDirectory.dir("signing").get().asFile
                    outDir.mkdirs()
                    File(outDir, "release-keystore.jks").apply { writeBytes(bytes) }
                }.getOrNull()

                !envKeystore.isNullOrEmpty() -> {
                    val candidate = rootProject.file(envKeystore)
                    if (candidate.isFile) {
                        candidate
                    } else {
                        runCatching {
                            val bytes = Base64.getMimeDecoder().decode(envKeystore)
                            val outDir = project.layout.buildDirectory.dir("signing").get().asFile
                            outDir.mkdirs()
                            File(outDir, "release-keystore.jks").apply { writeBytes(bytes) }
                        }.getOrNull()
                    }
                }

                else -> null
            }

            if (hasCredentials && releaseKeystore != null) {
                storeFile = releaseKeystore
                storePassword = envStorePassword
                keyAlias = envKeyAlias
                keyPassword = envKeyPassword
                project.logger.lifecycle("Release signing: keystore from AIBOX_RELEASE_* environment")
            } else {
                // Локальные сборки не должны ломаться из-за отсутствующих секретов.
                val fallback = project.file("debug.keystore")
                project.logger.warn(
                    "WARN: AIBOX_RELEASE_* secrets are missing or incomplete; " +
                        "release will be signed with app/debug.keystore"
                )
                if (!fallback.isFile) {
                    project.logger.warn("WARN: app/debug.keystore not found; release APK will be unsigned")
                }
                storeFile = fallback
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            buildConfigField("String", "UPDATE_CHANNEL", "\"release\"")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
            buildConfigField("String", "UPDATE_CHANNEL", "\"debug\"")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(project(":core:core-model"))
    implementation(project(":core:core-data"))
    implementation(project(":core:core-ui"))
    implementation(project(":launcher"))
    implementation(project(":desktop"))
    implementation(project(":dock"))
    implementation(project(":widgets"))
    implementation(project(":wallpaper"))
    implementation(project(":weather"))
    implementation(project(":control-center"))
    implementation(project(":app-drawer"))
    implementation(project(":settings"))
    implementation(project(":icons"))
    implementation(project(":gestures"))
    implementation(project(":system"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.material3)
}
