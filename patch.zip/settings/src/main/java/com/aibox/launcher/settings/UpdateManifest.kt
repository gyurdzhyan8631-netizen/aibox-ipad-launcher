package com.aibox.launcher.settings

import org.json.JSONArray
import org.json.JSONObject

// Дубли констант из :app (BuildConfig доступен только в модуле :app).
internal const val UPDATE_REPO = "gyurdzhyan8631-netizen/aibox-ipad-launcher"
internal const val UPDATE_MANIFEST_NAME = "update-manifest.json"

internal fun normalizeDigest(value: String): String = value
    .trim()
    .replace(":", "")
    .replace("-", "")
    .replace(" ", "")
    .lowercase()

internal fun isSha256(value: String): Boolean {
    val digest = normalizeDigest(value)
    return digest.length == 64 && digest.all { it in '0'..'9' || it in 'a'..'f' }
}

internal fun normalizeChannel(value: String): String = when (value.trim().lowercase()) {
    "prod", "production", "main" -> "release"
    else -> value.trim().lowercase()
}

/** Один APK, описанный манифестом обновления. */
internal data class ManifestVariant(
    val versionCode: Long,
    val versionName: String,
    val sha256: String,
    val size: Long,
    val minSdk: Int,
    val signatureSha256: String,
    val channel: String,
    /** https-URL либо имя ассета релиза. */
    val apkRef: String
)

/**
 * update-manifest.json из релиза GitHub. Поддерживаются оба вида:
 *  1) один APK в корне объекта;
 *  2) несколько APK в массиве `apks` / `artifacts` / `variants` / `builds` / `files`,
 *     либо массив объектов в корне файла.
 */
internal data class UpdateManifest(
    val variants: List<ManifestVariant>,
    /** Значение корневого поля `tag` манифеста, например "build-42". */
    val tag: String = "",
    val versionName: String = "",
    val versionCode: Long = 0L,
    val minSdk: Int = 0
) {

    /** APK для текущего applicationId; один APK без channel подходит для любого. */
    fun select(channel: String): ManifestVariant? {
        val wanted = normalizeChannel(channel)
        val byChannel = variants.firstOrNull { normalizeChannel(it.channel) == wanted }
        if (byChannel != null) return byChannel
        val single = variants.singleOrNull() ?: return null
        return single.takeIf { it.channel.isBlank() }
    }

    companion object {
        fun parse(body: String): UpdateManifest {
            val trimmed = body.trim()
            if (trimmed.startsWith("[")) return parse(JSONArray(trimmed))
            return parse(JSONObject(trimmed))
        }

        fun parse(array: JSONArray): UpdateManifest {
            val variants = mutableListOf<ManifestVariant>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                variants += variantFrom(obj, Defaults())
            }
            if (variants.isEmpty()) {
                throw IllegalArgumentException("В манифесте обновления нет APK")
            }
            return UpdateManifest(variants)
        }

        fun parse(json: JSONObject): UpdateManifest {
            val defaults = Defaults(
                versionCode = longOrNull(json, CODE_KEYS),
                versionName = firstString(json, NAME_KEYS),
                sha256 = firstString(json, SHA_KEYS),
                size = longOrNull(json, SIZE_KEYS) ?: 0L,
                minSdk = (longOrNull(json, MIN_SDK_KEYS) ?: 0L).coerceIn(0, 1_000).toInt(),
                signatureSha256 = firstString(json, SIGNATURE_KEYS),
                channel = normalizeChannel(firstString(json, CHANNEL_KEYS)),
                apkRef = firstString(json, APK_KEYS)
            )

            val variants = mutableListOf<ManifestVariant>()
            for (key in LIST_KEYS) {
                json.optJSONArray(key)?.let { array ->
                    for (i in 0 until array.length()) {
                        val obj = array.optJSONObject(i) ?: continue
                        variants += variantFrom(obj, defaults)
                    }
                }
                // Вариант формата: {"apks": {"debug": {...}, "release": {...}}}.
                json.optJSONObject(key)?.let { variants += variantsFromObject(it, defaults) }
            }
            // Вариант формата: корневые объекты "debug" / "release".
            for (key in listOf("debug", "release")) {
                json.optJSONObject(key)?.let { obj ->
                    variants += variantFrom(obj, defaults.copy(channel = normalizeChannel(key)))
                }
            }
            // Старый плоский формат: поля APK лежат в корне манифеста.
            if (variants.isEmpty()) variants += variantFrom(json, defaults)
            return UpdateManifest(
                variants = variants.distinctBy { "${it.channel}|${it.apkRef}|${it.sha256}" },
                tag = firstString(json, TAG_KEYS),
                versionName = defaults.versionName,
                versionCode = defaults.versionCode ?: 0L,
                minSdk = defaults.minSdk
            )
        }
    }
}

private val TAG_KEYS = listOf("tag", "tag_name", "buildTag")
private val CODE_KEYS = listOf("versionCode", "version_code", "build", "buildNumber")
private val NAME_KEYS = listOf("versionName", "version_name", "name")
private val SHA_KEYS = listOf("sha256", "sha256sum", "sha_256", "checksum")
private val SIZE_KEYS = listOf("size", "sizeBytes", "fileSize")
private val MIN_SDK_KEYS = listOf("minSdk", "minSdkVersion", "min_sdk")
private val SIGNATURE_KEYS = listOf("signatureSha256", "signature_sha256", "signerSha256")
private val CHANNEL_KEYS = listOf("channel", "variant", "flavor")
private val APK_KEYS = listOf("apkUrl", "apk_url", "apkAsset", "apk_asset", "apkName", "apk_name", "asset", "fileName", "file", "url")
private val LIST_KEYS = listOf("apks", "artifacts", "variants", "builds", "files")

private data class Defaults(
    val versionCode: Long? = null,
    val versionName: String = "",
    val sha256: String = "",
    val size: Long = 0L,
    val minSdk: Int = 0,
    val signatureSha256: String = "",
    val channel: String = "",
    val apkRef: String = ""
)

private fun variantsFromObject(container: JSONObject, defaults: Defaults): List<ManifestVariant> {
    val result = mutableListOf<ManifestVariant>()
    val names = container.names() ?: return result
    for (i in 0 until names.length()) {
        val key = names.getString(i)
        val obj = container.optJSONObject(key) ?: continue
        val keyedDefaults = if (obj.has("channel") || obj.has("variant") || obj.has("flavor")) {
            defaults
        } else {
            defaults.copy(channel = normalizeChannel(key))
        }
        result += variantFrom(obj, keyedDefaults)
    }
    return result
}

private fun variantFrom(obj: JSONObject, defaults: Defaults): ManifestVariant {
    val versionCode = longOrNull(obj, CODE_KEYS) ?: defaults.versionCode
        ?: throw IllegalArgumentException("В манифесте обновления нет versionCode")

    val sha256 = firstString(obj, SHA_KEYS).ifBlank { defaults.sha256 }
    if (!isSha256(sha256)) {
        throw IllegalArgumentException("В манифесте обновления пустой или некорректный sha256")
    }

    val apkRef = firstString(obj, APK_KEYS).ifBlank { defaults.apkRef }
    if (apkRef.isBlank()) {
        throw IllegalArgumentException("В манифесте обновления не указан APK")
    }

    val signatureSha256 = firstString(obj, SIGNATURE_KEYS).ifBlank { defaults.signatureSha256 }
    if (signatureSha256.isNotBlank() && !isSha256(signatureSha256)) {
        throw IllegalArgumentException("В манифесте обновления некорректный signatureSha256")
    }

    return ManifestVariant(
        versionCode = versionCode,
        versionName = firstString(obj, NAME_KEYS).ifBlank { defaults.versionName },
        sha256 = sha256,
        size = longOrNull(obj, SIZE_KEYS) ?: defaults.size,
        minSdk = (longOrNull(obj, MIN_SDK_KEYS) ?: defaults.minSdk.toLong())
            .coerceIn(0, 1_000).toInt(),
        signatureSha256 = signatureSha256,
        channel = normalizeChannel(firstString(obj, CHANNEL_KEYS).ifBlank { defaults.channel }),
        apkRef = apkRef
    )
}

private fun firstString(json: JSONObject, keys: List<String>): String {
    for (key in keys) {
        if (!json.has(key) || json.isNull(key)) continue
        val text = when (val raw = json.opt(key)) {
            is String -> raw.trim()
            is Number -> raw.toString()
            else -> ""
        }
        if (text.isNotBlank()) return text
    }
    return ""
}

private fun longOrNull(json: JSONObject, keys: List<String>): Long? {
    for (key in keys) {
        if (!json.has(key) || json.isNull(key)) continue
        val value = when (val raw = json.opt(key)) {
            is Number -> raw.toLong()
            is String -> raw.trim().toLongOrNull()
            else -> null
        }
        if (value != null) return value
    }
    return null
}
