package com.aibox.launcher.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Accessibility
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

private val blue = Color(0xFF0A84FF)
private val green = Color(0xFF30D158)
private val purple = Color(0xFFBF5AF2)
private val orange = Color(0xFFFF9F0A)
private val red = Color(0xFFFF453A)
private val cyan = Color(0xFF64D2FF)

private fun openSystem(context: Context, action: String) {
    runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure {
        Toast.makeText(context, "Системный раздел недоступен", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun choiceRow(
    title: String,
    subtitle: String?,
    choice: UiChoice,
    settings: LauncherSettings,
    onPick: (PickerRequest) -> Unit
) {
    val selected = settings.choice(choice)
    SettingsRow(
        icon = Icons.Rounded.Settings,
        iconColor = blue,
        title = title,
        value = UiChoice.label(choice.key, selected),
        subtitle = subtitle,
        onClick = {
            onPick(
                PickerRequest(
                    title = title,
                    options = UiChoice.options(choice.key).map {
                        PickerOption(it, UiChoice.label(choice.key, it))
                    },
                    selectedKey = selected,
                    onSelect = { settings.setChoice(choice, it) }
                )
            )
        }
    )
}

// ---------------------------------------------------------------- Онбординг

@Composable
internal fun OnboardingSection(settings: LauncherSettings, onOpenSection: (SettingsSection) -> Unit) {
    val context = LocalContext.current
    val done = remember(settings.onboardingDone) { settings.onboardingDone }
    SectionTitle("Первый запуск")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.Flag,
            iconColor = green,
            title = "Показывать подсказку",
            subtitle = "Открывается, пока лаунчер не настроен",
            checked = settings.flag(UiFlag.ONBOARDING),
            onCheckedChange = { settings.setFlag(UiFlag.ONBOARDING, it) }
        )
        RowDivider()
        SettingsRow(
            icon = Icons.Rounded.Home,
            iconColor = green,
            title = "Статус настройки",
            value = if (done) "Пройдена" else "Ожидает",
            subtitle = "Сделать лаунчером по умолчанию, включить доступность и установку",
            onClick = { settings.reopenOnboarding() }
        )
        RowDivider()
        SettingsRow(
            icon = Icons.Rounded.Check,
            iconColor = blue,
            title = "Сделать лаунчером по умолчанию",
            onClick = { openSystem(context, Settings.ACTION_HOME_SETTINGS) }
        )
        RowDivider()
        SettingsRow(
            icon = Icons.Rounded.Accessibility,
            iconColor = purple,
            title = "Включить Accessibility",
            subtitle = "Нужно для кнопок Back, Home и Recents",
            onClick = { openSystem(context, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        )
        RowDivider()
        SettingsRow(
            icon = Icons.Rounded.Settings,
            iconColor = orange,
            title = "Разрешить установку обновлений",
            onClick = {
                runCatching {
                    context.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:${context.packageName}")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
        )
    }
    HintText("Повторно открыть подсказку можно в любой момент кнопкой «Статус настройки».")
    PrimaryButton("Открыть раздел «Система»") { onOpenSection(SettingsSection.SYSTEM) }
}

// ---------------------------------------------------------------- Kiosk

@Composable
internal fun KioskSection(settings: LauncherSettings) {
    SectionTitle("Закрепление лаунчера")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.Lock,
            iconColor = red,
            title = "Режим киоска",
            subtitle = "Ограничить выход из автомобильного интерфейса",
            checked = settings.flag(UiFlag.KIOSK),
            onCheckedChange = { settings.setFlag(UiFlag.KIOSK, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Folder,
            iconColor = purple,
            title = "Скрыть «Все приложения»",
            checked = settings.flag(UiFlag.KIOSK_HIDE_DRAWER),
            onCheckedChange = { settings.setFlag(UiFlag.KIOSK_HIDE_DRAWER, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Refresh,
            iconColor = cyan,
            title = "Запретить перелистывание столов",
            checked = settings.flag(UiFlag.KIOSK_LOCK_PAGES),
            onCheckedChange = { settings.setFlag(UiFlag.KIOSK_LOCK_PAGES, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Settings,
            iconColor = blue,
            title = "Закрыть быструю шторку",
            checked = settings.flag(UiFlag.KIOSK_LOCK_PANEL),
            onCheckedChange = { settings.setFlag(UiFlag.KIOSK_LOCK_PANEL, it) }
        )
    }
    HintText("Настройки остаются доступны: выйти из режима киоска можно здесь же.")
}

// ---------------------------------------------------------------- Медиа

@Composable
internal fun MediaSection(settings: LauncherSettings, onPick: (PickerRequest) -> Unit) {
    SectionTitle("Музыка и медиа")
    SettingsGroup {
        choiceRow("Источник", "Откуда брать активную сессию", UiChoice.MEDIA_SOURCE, settings, onPick)
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.PlayArrow,
            iconColor = green,
            title = "Обложка и название трека",
            checked = settings.flag(UiFlag.MEDIA_COVER),
            onCheckedChange = { settings.setFlag(UiFlag.MEDIA_COVER, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Settings,
            iconColor = blue,
            title = "Прогресс воспроизведения",
            checked = settings.flag(UiFlag.MEDIA_PROGRESS),
            onCheckedChange = { settings.setFlag(UiFlag.MEDIA_PROGRESS, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Folder,
            iconColor = purple,
            title = "Очередь треков",
            checked = settings.flag(UiFlag.MEDIA_QUEUE),
            onCheckedChange = { settings.setFlag(UiFlag.MEDIA_QUEUE, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.VolumeUp,
            iconColor = orange,
            title = "Отдавать приоритет Bluetooth-аудио",
            checked = settings.flag(UiFlag.MEDIA_BT_SOURCE),
            onCheckedChange = { settings.setFlag(UiFlag.MEDIA_BT_SOURCE, it) }
        )
    }
    HintText("Приложение музыки выбирается в разделе «Приложения».")
}

// ---------------------------------------------------------------- Контраст

@Composable
internal fun ContrastSection(settings: LauncherSettings) {
    SectionTitle("Читаемость на любых обоях")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.Contrast,
            iconColor = blue,
            title = "Автоконтраст текста",
            subtitle = "Подложка под часами и статусом",
            checked = settings.flag(UiFlag.CONTRAST_AUTO),
            onCheckedChange = { settings.setFlag(UiFlag.CONTRAST_AUTO, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Contrast,
            iconColor = cyan,
            title = "Затемнять шапку",
            checked = settings.flag(UiFlag.CONTRAST_SCRIM),
            onCheckedChange = { settings.setFlag(UiFlag.CONTRAST_SCRIM, it) }
        )
        RowDivider()
        SliderRow(
            title = "Сила затемнения",
            valueText = "${(settings.number("contrast_strength") * 100).toInt()}%",
            value = settings.number("contrast_strength"),
            valueRange = 0.2f..0.95f,
            onValueChange = { settings.setNumber("contrast_strength", it) }
        )
    }
    HintText("Проверьте читаемость на светлых системных обоях.")
}

// ---------------------------------------------------------------- День/ночь

@Composable
internal fun DayNightSection(settings: LauncherSettings, onPick: (PickerRequest) -> Unit) {
    SectionTitle("День и ночь")
    SettingsGroup {
        choiceRow("Режим", "По времени или вручную", UiChoice.DAY_NIGHT, settings, onPick)
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.WbSunny,
            iconColor = orange,
            title = "Следовать времени суток",
            checked = settings.flag(UiFlag.DAY_NIGHT_AUTO),
            onCheckedChange = { settings.setFlag(UiFlag.DAY_NIGHT_AUTO, it) }
        )
    }
    HintText("Ночью текст и панели становятся светлее на тёмном фоне, днём — наоборот.")
}

// ---------------------------------------------------------------- Пустые состояния

@Composable
internal fun EmptyStatesSection(settings: LauncherSettings) {
    SectionTitle("Подсказки и ошибки")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.Home,
            iconColor = green,
            title = "Подсказка на пустом столе",
            checked = settings.flag(UiFlag.EMPTY_HINTS),
            onCheckedChange = { settings.setFlag(UiFlag.EMPTY_HINTS, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.ErrorOutline,
            iconColor = red,
            title = "Карточки ошибок",
            subtitle = "Нет сети, виджет недоступен, обновление не скачано",
            checked = settings.flag(UiFlag.EMPTY_ERRORS),
            onCheckedChange = { settings.setFlag(UiFlag.EMPTY_ERRORS, it) }
        )
    }
    HintText("Вместо молчаливого пустого экрана лаунчер показывает понятное действие.")
}

// ---------------------------------------------------------------- Адаптив

@Composable
internal fun AdaptiveSection(settings: LauncherSettings, onPick: (PickerRequest) -> Unit) {
    SectionTitle("Размеры и безопасные зоны")
    SettingsGroup {
        choiceRow("Соотношение сторон", "Под экран конкретного AI Box", UiChoice.ASPECT, settings, onPick)
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.AspectRatio,
            iconColor = cyan,
            title = "Безопасные отступы",
            subtitle = "Учитывать вырезы и системные панели",
            checked = settings.flag(UiFlag.ADAPTIVE_SAFE_AREA),
            onCheckedChange = { settings.setFlag(UiFlag.ADAPTIVE_SAFE_AREA, it) }
        )
        RowDivider()
        SliderRow(
            title = "Общий масштаб интерфейса",
            valueText = "${(settings.uiScale * 100).toInt()}%",
            value = settings.uiScale,
            valueRange = 0.6f..1.3f,
            onValueChange = { settings.updateUiScale(it) }
        )
    }
    HintText("Точная сетка виджетов 6×10 сохраняется на всех соотношениях сторон.")
}

// ---------------------------------------------------------------- Производительность

@Composable
internal fun PerformanceSection(settings: LauncherSettings) {
    SectionTitle("Лёгкий режим")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.Speed,
            iconColor = orange,
            title = "Лёгкий режим",
            subtitle = "Меньше анимаций и blur на слабом устройстве",
            checked = settings.flag(UiFlag.LITE_MODE),
            onCheckedChange = { settings.setFlag(UiFlag.LITE_MODE, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.PlayArrow,
            iconColor = green,
            title = "Видео-обои",
            checked = settings.flag(UiFlag.VIDEO_WALLPAPER),
            onCheckedChange = { settings.setFlag(UiFlag.VIDEO_WALLPAPER, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Contrast,
            iconColor = purple,
            title = "Размытие панелей",
            checked = settings.flag(UiFlag.BLUR),
            onCheckedChange = { settings.setFlag(UiFlag.BLUR, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Refresh,
            iconColor = blue,
            title = "Анимации интерфейса",
            checked = settings.flag(UiFlag.ANIMATIONS),
            onCheckedChange = { settings.setFlag(UiFlag.ANIMATIONS, it) }
        )
    }
    HintText("Лёгкий режим автоматически отключает видео-обои и ручные анимации.")
}

// ---------------------------------------------------------------- Уведомления

@Composable
internal fun NotificationsSection(settings: LauncherSettings) {
    val context = LocalContext.current
    SectionTitle("Шторка и уведомления")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.DirectionsCar,
            iconColor = green,
            title = "Навигация в шторке",
            checked = settings.flag(UiFlag.NOTIF_NAV),
            onCheckedChange = { settings.setFlag(UiFlag.NOTIF_NAV, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.PlayArrow,
            iconColor = purple,
            title = "Музыка в шторке",
            checked = settings.flag(UiFlag.NOTIF_MEDIA),
            onCheckedChange = { settings.setFlag(UiFlag.NOTIF_MEDIA, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Notifications,
            iconColor = blue,
            title = "Системная шторка по swipe",
            subtitle = "EXPAND_STATUS_BAR вместо кастомной панели",
            checked = settings.flag(UiFlag.NOTIF_SYSTEM_SHADE),
            onCheckedChange = { settings.setFlag(UiFlag.NOTIF_SYSTEM_SHADE, it) }
        )
        RowDivider()
        SettingsRow(
            icon = Icons.Rounded.Settings,
            iconColor = orange,
            title = "Доступ к уведомлениям",
            subtitle = "Нужен, чтобы показывать действия навигатора и плеера",
            onClick = { openSystem(context, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        )
    }
}

// ---------------------------------------------------------------- Авторежим

@Composable
internal fun AutomotiveSection(settings: LauncherSettings) {
    SectionTitle("Автомобильный интерфейс")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.DirectionsCar,
            iconColor = orange,
            title = "Автомобильный режим",
            subtitle = "Крупные элементы, минимум отвлечений",
            checked = settings.flag(UiFlag.AUTOMOTIVE),
            onCheckedChange = { settings.setFlag(UiFlag.AUTOMOTIVE, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Accessibility,
            iconColor = blue,
            title = "Увеличенные кнопки",
            checked = settings.flag(UiFlag.AUTOMOTIVE_LARGE),
            onCheckedChange = { settings.setFlag(UiFlag.AUTOMOTIVE_LARGE, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Speed,
            iconColor = cyan,
            title = "Спокойные анимации",
            checked = settings.flag(UiFlag.AUTOMOTIVE_QUIET),
            onCheckedChange = { settings.setFlag(UiFlag.AUTOMOTIVE_QUIET, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.DirectionsCar,
            iconColor = green,
            title = "Навигация в приоритете",
            checked = settings.flag(UiFlag.AUTOMOTIVE_NAV_PRIORITY),
            onCheckedChange = { settings.setFlag(UiFlag.AUTOMOTIVE_NAV_PRIORITY, it) }
        )
    }
    HintText("Рекомендуется включить вместе с лёгким режимом.")
}

// ---------------------------------------------------------------- Телефон

@Composable
internal fun PhoneSection(settings: LauncherSettings) {
    val context = LocalContext.current
    SectionTitle("Звонки")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.Phone,
            iconColor = green,
            title = "Телефон в доке",
            checked = settings.flag(UiFlag.PHONE_DOCK),
            onCheckedChange = { settings.setFlag(UiFlag.PHONE_DOCK, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Phone,
            iconColor = blue,
            title = "Быстрый набор",
            checked = settings.flag(UiFlag.PHONE_QUICK_DIAL),
            onCheckedChange = { settings.setFlag(UiFlag.PHONE_QUICK_DIAL, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Refresh,
            iconColor = purple,
            title = "Последние вызовы",
            checked = settings.flag(UiFlag.PHONE_RECENTS),
            onCheckedChange = { settings.setFlag(UiFlag.PHONE_RECENTS, it) }
        )
        RowDivider()
        SettingsRow(
            icon = Icons.Rounded.Phone,
            iconColor = orange,
            title = "Открыть телефон",
            subtitle = "Через системный ACTION_DIAL",
            onClick = {
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure { Toast.makeText(context, "Телефон не установлен", Toast.LENGTH_SHORT).show() }
            }
        )
    }
    HintText("Журнал вызовов не читается: лаунчер только открывает системное приложение.")
}

// ---------------------------------------------------------------- Папки и страницы

@Composable
internal fun AppsOrganizeSection(settings: LauncherSettings) {
    SectionTitle("Приложения и страницы")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.Folder,
            iconColor = purple,
            title = "Папки приложений",
            checked = settings.flag(UiFlag.APPS_FOLDERS),
            onCheckedChange = { settings.setFlag(UiFlag.APPS_FOLDERS, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Search,
            iconColor = blue,
            title = "Поиск в меню приложений",
            checked = settings.flag(UiFlag.APPS_SEARCH),
            onCheckedChange = { settings.setFlag(UiFlag.APPS_SEARCH, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.AspectRatio,
            iconColor = cyan,
            title = "Три стола вместо двух",
            subtitle = "Дополнительная страница для виджетов",
            checked = settings.flag(UiFlag.APPS_THREE_PAGES),
            onCheckedChange = { settings.setFlag(UiFlag.APPS_THREE_PAGES, it) }
        )
    }
    HintText("Покачивание и свободный перенос виджетов работают на всех столах.")
}

// ---------------------------------------------------------------- Жесты

@Composable
internal fun GesturesSection(settings: LauncherSettings, onPick: (PickerRequest) -> Unit) {
    SectionTitle("Настройки жестов")
    SettingsGroup {
        choiceRow("Свайп влево", "Действие", UiChoice.SWIPE_LEFT, settings, onPick)
        RowDivider()
        choiceRow("Свайп вправо", "Действие", UiChoice.SWIPE_RIGHT, settings, onPick)
        RowDivider()
        choiceRow("Долгое нажатие", "Действие", UiChoice.LONG_PRESS, settings, onPick)
        RowDivider()
        choiceRow("Двойное касание", "Действие", UiChoice.DOUBLE_TAP, settings, onPick)
    }
    HintText("Свайп вниз от верхнего края открывает шторку; в режиме правки жесты отключены.")
}

// ---------------------------------------------------------------- Обратная связь

@Composable
internal fun FeedbackSection(settings: LauncherSettings) {
    SectionTitle("Звук и вибрация")
    SettingsGroup {
        SwitchRow(
            icon = Icons.Rounded.VolumeUp,
            iconColor = blue,
            title = "Звук нажатия",
            checked = settings.flag(UiFlag.FEEDBACK_SOUND),
            onCheckedChange = { settings.setFlag(UiFlag.FEEDBACK_SOUND, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Vibration,
            iconColor = purple,
            title = "Вибрация",
            checked = settings.flag(UiFlag.FEEDBACK_VIBRATION),
            onCheckedChange = { settings.setFlag(UiFlag.FEEDBACK_VIBRATION, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.TouchApp,
            iconColor = green,
            title = "Хаптика кнопок",
            checked = settings.flag(UiFlag.FEEDBACK_HAPTIC),
            onCheckedChange = { settings.setFlag(UiFlag.FEEDBACK_HAPTIC, it) }
        )
    }
}

// ---------------------------------------------------------------- Доступность

@Composable
internal fun AccessibilitySection(settings: LauncherSettings, onPick: (PickerRequest) -> Unit) {
    val context = LocalContext.current
    SectionTitle("Язык и доступность")
    SettingsGroup {
        choiceRow("Язык интерфейса", "Системный, русский или английский", UiChoice.LANGUAGE, settings, onPick)
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Accessibility,
            iconColor = blue,
            title = "Крупный текст",
            checked = settings.flag(UiFlag.ACCESS_LARGE_TEXT),
            onCheckedChange = { settings.setFlag(UiFlag.ACCESS_LARGE_TEXT, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.Check,
            iconColor = green,
            title = "Подписи для TalkBack",
            checked = settings.flag(UiFlag.ACCESS_TALKBACK),
            onCheckedChange = { settings.setFlag(UiFlag.ACCESS_TALKBACK, it) }
        )
        RowDivider()
        SwitchRow(
            icon = Icons.Rounded.AspectRatio,
            iconColor = purple,
            title = "Поддержка RTL",
            checked = settings.flag(UiFlag.ACCESS_RTL),
            onCheckedChange = { settings.setFlag(UiFlag.ACCESS_RTL, it) }
        )
        RowDivider()
        SettingsRow(
            icon = Icons.Rounded.Accessibility,
            iconColor = orange,
            title = "Системные настройки доступности",
            onClick = { openSystem(context, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        )
    }
    HintText("Хардкод-строки вынесены в ресурсы; язык применяется после перезапуска лаунчера.")
}

// ---------------------------------------------------------------- Сброс

@Composable
internal fun ResetInterfaceSection(settings: LauncherSettings) {
    SectionTitle("Сброс интерфейса")
    SettingsGroup {
        SettingsRow(
            icon = Icons.Rounded.Restore,
            iconColor = orange,
            title = "Сбросить новые настройки",
            subtitle = "Онбординг, киоск, жесты, контраст и т.д.",
            onClick = { settings.resetInterfaceSettings() }
        )
        RowDivider()
        SettingsRow(
            icon = Icons.Rounded.Refresh,
            iconColor = red,
            title = "Показать подсказку заново",
            onClick = { settings.reopenOnboarding() }
        )
    }
}
