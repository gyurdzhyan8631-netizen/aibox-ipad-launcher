package com.aibox.launcher.settings

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aibox.launcher.core.model.VisualStyle
import com.aibox.launcher.core.model.WallpaperType
import com.aibox.launcher.core.model.WidgetStyle
import com.aibox.launcher.core.ui.LauncherFonts
import com.aibox.launcher.widgets.WIDGET_GRID_COLUMNS
import com.aibox.launcher.widgets.WIDGET_GRID_ROWS
import com.aibox.launcher.widgets.WidgetItem
import com.aibox.launcher.widgets.WidgetSizeClass
import com.aibox.launcher.widgets.defaultWidgetBoard
import com.aibox.launcher.widgets.encodeBoard
import com.aibox.launcher.widgets.firstFreeWidgetSpot
import com.aibox.launcher.widgets.parseBoard

enum class ClockStyle(val id: String, val title: String) {
    BOLD("bold", "Жирный"),
    LIGHT("light", "Тонкий"),
    SAMSUNG("samsung", "Samsung"),
    IPHONE("iphone", "iPhone"),
    PIXEL("pixel", "Google Pixel");

    companion object {
        fun fromId(id: String?): ClockStyle = entries.firstOrNull { it.id == id } ?: LIGHT
    }
}

/** Откуда лаунчер берёт погоду для виджетов. */
enum class WeatherSource(val id: String, val title: String) {
    CITY("city", "Город вручную"),
    GPS("gps", "По GPS");

    companion object {
        fun fromId(id: String?): WeatherSource = entries.firstOrNull { it.id == id } ?: CITY
    }
}

/**
 * Флаги новых разделов интерфейса. Хранятся в одном preface-пространстве и читаются
 * как Compose-состояние, поэтому переключатель сразу применяется на экране.
 */
enum class UiFlag(val key: String, val default: Boolean) {
    ONBOARDING("onboarding_enabled", true),
    KIOSK("kiosk_mode", false),
    KIOSK_HIDE_DRAWER("kiosk_hide_drawer", false),
    KIOSK_LOCK_PAGES("kiosk_lock_pages", false),
    KIOSK_LOCK_PANEL("kiosk_lock_panel", false),
    MEDIA_COVER("media_show_cover", true),
    MEDIA_PROGRESS("media_show_progress", true),
    MEDIA_QUEUE("media_show_queue", false),
    MEDIA_BT_SOURCE("media_source_bluetooth", false),
    CONTRAST_AUTO("contrast_auto", true),
    CONTRAST_SCRIM("contrast_scrim", true),
    DAY_NIGHT_AUTO("day_night_auto", false),
    EMPTY_HINTS("empty_hints", true),
    EMPTY_ERRORS("empty_errors", true),
    ADAPTIVE_SAFE_AREA("adaptive_safe_area", true),
    LITE_MODE("lite_mode", false),
    BLUR("blur_enabled", true),
    ANIMATIONS("animations_enabled", true),
    VIDEO_WALLPAPER("video_wallpaper", true),
    NOTIF_NAV("notif_nav", true),
    NOTIF_MEDIA("notif_media", true),
    NOTIF_SYSTEM_SHADE("notif_system_shade", false),
    AUTOMOTIVE("automotive_mode", false),
    AUTOMOTIVE_LARGE("automotive_large_buttons", true),
    AUTOMOTIVE_QUIET("automotive_quiet_anim", true),
    AUTOMOTIVE_NAV_PRIORITY("automotive_nav_priority", true),
    PHONE_DOCK("phone_in_dock", true),
    PHONE_QUICK_DIAL("phone_quick_dial", true),
    PHONE_RECENTS("phone_recents", false),
    APPS_FOLDERS("apps_folders", false),
    APPS_SEARCH("apps_search", true),
    APPS_THREE_PAGES("apps_three_pages", false),
    GESTURE_SWIPE_LEFT("gesture_swipe_left", true),
    GESTURE_SWIPE_RIGHT("gesture_swipe_right", true),
    GESTURE_LONG_PRESS("gesture_long_press", true),
    GESTURE_DOUBLE_TAP("gesture_double_tap", false),
    FEEDBACK_SOUND("feedback_sound", false),
    FEEDBACK_VIBRATION("feedback_vibration", true),
    FEEDBACK_HAPTIC("feedback_haptic", true),
    ACCESS_LARGE_TEXT("access_large_text", false),
    ACCESS_TALKBACK("access_talkback", true),
    ACCESS_RTL("access_rtl", false),
    UPDATE_AUTO_CHECK("update_auto_check", true);
}

/** Выборы в новых разделах интерфейса. */
enum class UiChoice(val key: String, val default: String) {
    DAY_NIGHT("day_night_mode", "auto"),
    ASPECT("adaptive_aspect", "auto"),
    MEDIA_SOURCE("media_source", "auto"),
    SWIPE_LEFT("gesture_left_action", "previous_page"),
    SWIPE_RIGHT("gesture_right_action", "next_page"),
    LONG_PRESS("gesture_long_action", "edit_widgets"),
    DOUBLE_TAP("gesture_double_action", "quick_panel"),
    LANGUAGE("ui_language", "system");

    companion object {
        fun options(key: String): List<String> = when (key) {
            DAY_NIGHT.key -> listOf("auto", "day", "night")
            ASPECT.key -> listOf("auto", "16:9", "18:9", "21:9")
            MEDIA_SOURCE.key -> listOf("auto", "bluetooth", "youtube", "local")
            SWIPE_LEFT.key, SWIPE_RIGHT.key ->
                listOf("none", "previous_page", "next_page", "quick_panel", "app_drawer", "music")
            LONG_PRESS.key -> listOf("edit_widgets", "quick_panel", "none")
            DOUBLE_TAP.key -> listOf("quick_panel", "app_drawer", "none")
            LANGUAGE.key -> listOf("system", "ru", "en")
            else -> emptyList()
        }

        fun label(key: String, value: String): String = when (key) {
            DAY_NIGHT.key -> when (value) {
                "day" -> "День"; "night" -> "Ночь"; else -> "Авто (по времени)"
            }
            ASPECT.key -> if (value == "auto") "Авто" else value
            MEDIA_SOURCE.key -> when (value) {
                "bluetooth" -> "Bluetooth"; "youtube" -> "YouTube"; "local" -> "Локальная"; else -> "Авто"
            }
            SWIPE_LEFT.key, SWIPE_RIGHT.key -> when (value) {
                "none" -> "Ничего"; "previous_page" -> "Предыдущий стол"; "next_page" -> "Следующий стол"
                "quick_panel" -> "Шторка"; "app_drawer" -> "Все приложения"; "music" -> "Музыка"
                else -> value
            }
            LONG_PRESS.key -> when (value) {
                "edit_widgets" -> "Правка виджетов"; "quick_panel" -> "Шторка"; else -> "Ничего"
            }
            DOUBLE_TAP.key -> when (value) {
                "quick_panel" -> "Шторка"; "app_drawer" -> "Все приложения"; else -> "Ничего"
            }
            LANGUAGE.key -> when (value) {
                "ru" -> "Русский"; "en" -> "English"; else -> "Системный"
            }
            else -> value
        }
    }
}

/** Шрифты и часы, которые задаёт выбранная обложка стиля OS. */
private data class OsPreset(
    val clock: ClockStyle,
    val interfaceFont: String,
    val clockFont: String,
    val dateFont: String,
    val greetingFont: String
)

/**
 * Все настройки лаунчера. Значения хранятся в SharedPreferences и сразу применяются на экране
 * (это Compose-состояние).
 */
class LauncherSettings(private val prefs: SharedPreferences) {

    init {
        // Старая система виджетов больше не используется — чистим её ключи при первом запуске.
        if (prefs.contains(K_P1) || prefs.contains(K_P2) || prefs.contains(K_SIZES) ||
            prefs.contains(K_WIDGET) || prefs.contains("widget_board_size_v2")
        ) {
            prefs.edit()
                .remove(K_P1)
                .remove(K_P2)
                .remove(K_SIZES)
                .remove(K_WIDGET)
                .remove("widget_board_size_v2")
                .apply()
        }
        // Записи старого формата (с typeId) больше не читаются — удаляем сразу.
        listOf(K_BOARD1, K_BOARD2).forEach { key ->
            val raw = prefs.getString(key, null)
            if (!raw.isNullOrBlank() && parseBoard(raw, emptyList()).isEmpty()) {
                prefs.edit().remove(key).apply()
            }
        }

        // Старая система обоев (темы, фото, живое небо, динамические сцены) больше не используется.
        val legacyWallpaperKeys = listOf(
            "wallpaper_theme", "sky_precip", "dynamic_scene_wallpaper",
            "dynamic_scene_pack", "dynamic_scene_id", "scene_rotation",
            "scene_seconds", "scene_glass_clock"
        )
        if (legacyWallpaperKeys.any { prefs.contains(it) }) {
            val editor = prefs.edit()
            legacyWallpaperKeys.forEach { editor.remove(it) }
            editor.apply()
        }
        if (prefs.getString(K_WP_TYPE, null) !in setOf("video", "system")) {
            prefs.edit().putString(K_WP_TYPE, "system").putString(K_WP_PATH, "").apply()
        }

    }

    var panelScale by mutableFloatStateOf(prefs.getFloat(K_PANEL, 1f).coerceIn(0.75f, 1.35f))
        private set
    var iconScale by mutableFloatStateOf(prefs.getFloat(K_ICON, 1f).coerceIn(0.7f, 1.5f))
        private set
    var clockScale by mutableFloatStateOf(prefs.getFloat(K_CLOCK, 1f).coerceIn(0.6f, 1.4f))
        private set

    /** Масштаб всего интерфейса (по умолчанию чуть меньше, чем «как есть»). */
    var uiScale by mutableFloatStateOf(prefs.getFloat(K_UI, DEFAULT_UI_SCALE).coerceIn(0.6f, 1.3f))
        private set
    var statusScale by mutableFloatStateOf(prefs.getFloat(K_STATUS, 1f).coerceIn(0.6f, 1.3f))
        private set
    var quickScale by mutableFloatStateOf(prefs.getFloat(K_QUICK, 1f).coerceIn(0.6f, 1.3f))
        private set

    /** Масштаб виджетов на рабочих столах: 60–160%, независимо от общего масштаба. */
    var widgetScale by mutableFloatStateOf(
        prefs.getFloat(K_WIDGET_SCALE, 1f).coerceIn(0.6f, 1.6f)
    )
        private set

    /** Док и капсула горячих клавиш теперь настраиваются отдельно друг от друга. */
    var dockScale by mutableFloatStateOf(
        prefs.getFloat(K_DOCK, prefs.getFloat(K_PANEL, 1f)).coerceIn(0.75f, 1.35f)
    )
        private set
    var hotkeyScale by mutableFloatStateOf(
        prefs.getFloat(K_HOTKEY, prefs.getFloat(K_PANEL, 1f)).coerceIn(0.75f, 1.35f)
    )
        private set

    var clockStyle by mutableStateOf(ClockStyle.fromId(prefs.getString(K_CLOCK_STYLE, null)))
        private set
    var interfaceFontId by mutableStateOf(
        prefs.getString(K_INTERFACE_FONT, LauncherFonts.DEFAULT_ID) ?: LauncherFonts.DEFAULT_ID
    )
        private set
    var clockFontId by mutableStateOf(
        prefs.getString(K_CLOCK_FONT, LauncherFonts.DEFAULT_ID) ?: LauncherFonts.DEFAULT_ID
    )
        private set
    var dateFontId by mutableStateOf(
        prefs.getString(K_DATE_FONT, LauncherFonts.DEFAULT_ID) ?: LauncherFonts.DEFAULT_ID
    )
        private set
    var greetingFontId by mutableStateOf(
        prefs.getString(K_GREETING_FONT, LauncherFonts.DEFAULT_ID) ?: LauncherFonts.DEFAULT_ID
    )
        private set

    /** Брендовый стиль из раздела «Стили OS». Управляет цветами интерфейса. */
    var visualStyle by mutableStateOf(VisualStyle.fromId(prefs.getString(K_VISUAL_STYLE, null)))
        private set

    /** Стиль системных виджетов: выбирается в «Размеры», по умолчанию идёт от стиля OS. */
    var widgetStyle by mutableStateOf(
        WidgetStyle.fromId(prefs.getString(K_WIDGET_STYLE, null) ?: WidgetStyle.forVisualStyle(visualStyle).id)
    )
        private set

    var musicPackage by mutableStateOf(prefs.getString(K_MUSIC, "") ?: "")
        private set
    var navPackage by mutableStateOf(prefs.getString(K_NAV, "") ?: "")
        private set
    var weatherPackage by mutableStateOf(prefs.getString(K_WEATHER, "") ?: "")
        private set
    var videoPackage by mutableStateOf(prefs.getString(K_VIDEO, "") ?: "")
        private set
    var city by mutableStateOf(prefs.getString(K_CITY, "") ?: "")
        private set
    var weatherSource by mutableStateOf(WeatherSource.fromId(prefs.getString(K_WEATHER_SOURCE, null)))
        private set

    /** Новая iPad-система: позиции виджетов хранятся в ячейках сетки 6×10. */
    var widgetBoard1 by mutableStateOf(
        parseBoard(prefs.getString(K_BOARD1, null), defaultWidgetBoard(1))
    )
        private set
    var widgetBoard2 by mutableStateOf(
        parseBoard(prefs.getString(K_BOARD2, null), defaultWidgetBoard(2))
    )
        private set

    var wallpaperType by mutableStateOf(WallpaperType.fromId(prefs.getString(K_WP_TYPE, null)))
        private set
    var wallpaperPath by mutableStateOf(prefs.getString(K_WP_PATH, "") ?: "")
        private set

    // --- Новые разделы интерфейса: флаги, выборы и числа ---

    private val uiFlags = mutableStateMapOf<String, Boolean>().apply {
        UiFlag.entries.forEach { put(it.key, prefs.getBoolean("flag_${it.key}", it.default)) }
    }
    private val uiChoices = mutableStateMapOf<String, String>().apply {
        UiChoice.entries.forEach { put(it.key, prefs.getString("choice_${it.key}", null) ?: it.default) }
    }
    private val uiNumbers = mutableStateMapOf<String, Float>().apply {
        put(K_CONTRAST, prefs.getFloat(K_CONTRAST, 0.65f))
        put(K_TEXT_SIZE, prefs.getFloat(K_TEXT_SIZE, 1f))
    }

    fun flag(flag: UiFlag): Boolean = uiFlags[flag.key] ?: flag.default

    fun setFlag(flag: UiFlag, value: Boolean) {
        uiFlags[flag.key] = value
        prefs.edit().putBoolean("flag_${flag.key}", value).apply()
    }

    fun choice(choice: UiChoice): String = uiChoices[choice.key] ?: choice.default

    fun setChoice(choice: UiChoice, value: String) {
        uiChoices[choice.key] = value
        prefs.edit().putString("choice_${choice.key}", value).apply()
    }

    fun number(key: String): Float = uiNumbers[key] ?: 0f

    fun setNumber(key: String, value: Float) {
        uiNumbers[key] = value
        prefs.edit().putFloat(key, value).apply()
    }

    /** Онбординг показывается один раз, пока пользователь не нажал «Готово». */
    var onboardingDone: Boolean by mutableStateOf(prefs.getBoolean(K_ONBOARDING_DONE, false))
        private set

    fun markOnboardingDone() {
        onboardingDone = true
        prefs.edit().putBoolean(K_ONBOARDING_DONE, true).apply()
    }

    fun reopenOnboarding() {
        onboardingDone = false
        prefs.edit().putBoolean(K_ONBOARDING_DONE, false).apply()
    }

    fun resetInterfaceSettings() {
        UiFlag.entries.forEach { setFlag(it, it.default) }
        UiChoice.entries.forEach { setChoice(it, it.default) }
        setNumber(K_CONTRAST, 0.65f)
        setNumber(K_TEXT_SIZE, 1f)
    }

    fun updatePanelScale(value: Float) {
        panelScale = value.coerceIn(0.75f, 1.35f)
        prefs.edit().putFloat(K_PANEL, panelScale).apply()
    }

    fun updateIconScale(value: Float) {
        iconScale = value.coerceIn(0.7f, 1.5f)
        prefs.edit().putFloat(K_ICON, iconScale).apply()
    }

    fun updateClockScale(value: Float) {
        clockScale = value.coerceIn(0.6f, 1.4f)
        prefs.edit().putFloat(K_CLOCK, clockScale).apply()
    }

    fun updateClockStyle(value: ClockStyle) {
        clockStyle = value
        prefs.edit().putString(K_CLOCK_STYLE, value.id).apply()
    }

    fun updateInterfaceFont(value: String) {
        interfaceFontId = value
        prefs.edit().putString(K_INTERFACE_FONT, value).apply()
    }

    fun updateClockFont(value: String) {
        clockFontId = value
        prefs.edit().putString(K_CLOCK_FONT, value).apply()
    }

    fun updateDateFont(value: String) {
        dateFontId = value
        prefs.edit().putString(K_DATE_FONT, value).apply()
    }

    fun updateGreetingFont(value: String) {
        greetingFontId = value
        prefs.edit().putString(K_GREETING_FONT, value).apply()
    }

    /**
     * Обложка стиля OS задаёт не только цвета, но и часы, и шрифты даты/приветствия.
     * Остальные настройки (масштабы, обои) не сбрасываются.
     */
    fun applyOsStyle(value: VisualStyle) {
        visualStyle = value
        widgetStyle = WidgetStyle.forVisualStyle(value)
        val preset = when (value) {
            VisualStyle.IPAD -> OsPreset(
                ClockStyle.IPHONE, "sans", "sans", "sans", "sans"
            )
            VisualStyle.SAMSUNG_TAB -> OsPreset(
                ClockStyle.SAMSUNG, "system", "system", "system", "system"
            )
            VisualStyle.APPLE_DUO -> OsPreset(
                ClockStyle.IPHONE, "sans", "sans", "serif", "sans"
            )
            VisualStyle.PIXEL_FOLD -> OsPreset(
                ClockStyle.PIXEL, "system", "system", "sans", "sans"
            )
            else -> null
        }
        if (preset != null) {
            clockStyle = preset.clock
            interfaceFontId = preset.interfaceFont
            clockFontId = preset.clockFont
            dateFontId = preset.dateFont
            greetingFontId = preset.greetingFont
        }
        prefs.edit()
            .putString(K_VISUAL_STYLE, value.name)
            .putString(K_WIDGET_STYLE, widgetStyle.id)
            .putString(K_CLOCK_STYLE, clockStyle.id)
            .putString(K_INTERFACE_FONT, interfaceFontId)
            .putString(K_CLOCK_FONT, clockFontId)
            .putString(K_DATE_FONT, dateFontId)
            .putString(K_GREETING_FONT, greetingFontId)
            .apply()
    }

    /** Выбор стиля виджетов из раздела «Размеры» не меняет часы, шрифты и цвета интерфейса. */
    fun updateWidgetStyle(value: WidgetStyle) {
        widgetStyle = value
        prefs.edit().putString(K_WIDGET_STYLE, value.id).apply()
    }

    fun updateMusicPackage(value: String) {
        musicPackage = value
        prefs.edit().putString(K_MUSIC, value).apply()
    }

    fun updateNavPackage(value: String) {
        navPackage = value
        prefs.edit().putString(K_NAV, value).apply()
    }

    fun updateWeatherPackage(value: String) {
        weatherPackage = value
        prefs.edit().putString(K_WEATHER, value).apply()
    }

    fun updateVideoPackage(value: String) {
        videoPackage = value
        prefs.edit().putString(K_VIDEO, value).apply()
    }

    fun updateCity(value: String) {
        city = value.trim()
        prefs.edit().putString(K_CITY, city).apply()
    }

    fun updateWeatherSource(value: WeatherSource) {
        weatherSource = value
        prefs.edit().putString(K_WEATHER_SOURCE, value.id).apply()
    }

    fun widgetBoard(page: Int): List<WidgetItem> = if (page == 1) widgetBoard1 else widgetBoard2

    private fun storeBoard(page: Int, items: List<WidgetItem>) {
        val encoded = encodeBoard(items)
        if (page == 1) {
            widgetBoard1 = items
            prefs.edit().putString(K_BOARD1, encoded).apply()
        } else {
            widgetBoard2 = items
            prefs.edit().putString(K_BOARD2, encoded).apply()
        }
    }

    /** Добавление системного AppWidget после выбора в пикере Android. */
    fun addHostedWidget(
        page: Int,
        appWidgetId: Int,
        size: WidgetSizeClass = WidgetSizeClass.MEDIUM
    ): WidgetItem {
        val current = widgetBoard(page)
        val (column, row) = firstFreeWidgetSpot(current, size)
        val item = WidgetItem(
            id = appWidgetId.toString(),
            appWidgetId = appWidgetId,
            size = size,
            column = column,
            row = row
        )
        storeBoard(page, current + item)
        return item
    }

    fun removeWidget(page: Int, id: String) {
        storeBoard(page, widgetBoard(page).filter { it.id != id })
    }

    /** Перенос в любую ячейку сетки: пересечения разрешены, зарезервированных зон нет. */
    fun moveWidget(page: Int, id: String, column: Int, row: Int) {
        val current = widgetBoard(page)
        val item = current.firstOrNull { it.id == id } ?: return
        val maxColumn = (WIDGET_GRID_COLUMNS - item.size.columns).coerceAtLeast(0)
        val maxRow = (WIDGET_GRID_ROWS - item.size.rows).coerceAtLeast(0)
        val targetColumn = column.coerceIn(0, maxColumn)
        val targetRow = row.coerceIn(0, maxRow)
        storeBoard(
            page,
            current.map {
                if (it.id == id) it.copy(column = targetColumn, row = targetRow) else it
            }
        )
    }

    fun resizeWidget(page: Int, id: String, size: WidgetSizeClass) {
        val current = widgetBoard(page)
        val item = current.firstOrNull { it.id == id } ?: return
        val maxColumn = (WIDGET_GRID_COLUMNS - size.columns).coerceAtLeast(0)
        val maxRow = (WIDGET_GRID_ROWS - size.rows).coerceAtLeast(0)
        storeBoard(
            page,
            current.map {
                if (it.id == id) {
                    it.copy(
                        size = size,
                        column = it.column.coerceIn(0, maxColumn),
                        row = it.row.coerceIn(0, maxRow)
                    )
                } else {
                    it
                }
            }
        )
    }

    fun resetWidgetBoards() {
        storeBoard(1, defaultWidgetBoard(1))
        storeBoard(2, defaultWidgetBoard(2))
    }

    fun updateUiScale(value: Float) {
        uiScale = value.coerceIn(0.6f, 1.3f)
        prefs.edit().putFloat(K_UI, uiScale).apply()
    }

    fun updateStatusScale(value: Float) {
        statusScale = value.coerceIn(0.6f, 1.3f)
        prefs.edit().putFloat(K_STATUS, statusScale).apply()
    }

    fun updateQuickScale(value: Float) {
        quickScale = value.coerceIn(0.6f, 1.3f)
        prefs.edit().putFloat(K_QUICK, quickScale).apply()
    }

    fun updateWidgetScale(value: Float) {
        widgetScale = value.coerceIn(0.6f, 1.6f)
        prefs.edit().putFloat(K_WIDGET_SCALE, widgetScale).apply()
    }

    fun updateDockScale(value: Float) {
        dockScale = value.coerceIn(0.75f, 1.35f)
        prefs.edit().putFloat(K_DOCK, dockScale).apply()
    }

    fun updateHotkeyScale(value: Float) {
        hotkeyScale = value.coerceIn(0.75f, 1.35f)
        prefs.edit().putFloat(K_HOTKEY, hotkeyScale).apply()
    }

    /** Возвращает все размеры к значениям по умолчанию. */
    fun resetSizes() {
        updateUiScale(DEFAULT_UI_SCALE)
        updateStatusScale(1f)
        updateQuickScale(1f)
        updateWidgetScale(1f)
        updatePanelScale(1f)
        updateDockScale(1f)
        updateHotkeyScale(1f)
        updateIconScale(1f)
        updateClockScale(1f)
    }

    fun selectWallpaper(type: WallpaperType, path: String = "") {
        wallpaperType = type
        wallpaperPath = path
        prefs.edit().putString(K_WP_TYPE, type.id).putString(K_WP_PATH, path).apply()
    }

    /** Файл обоев удалён с устройства — вернуться к системным обоям. */
    fun wallpaperFileDeleted(path: String) {
        if (wallpaperPath == path) selectWallpaper(WallpaperType.SYSTEM)
    }

    private companion object {
        const val DEFAULT_UI_SCALE = 0.85f
        const val K_UI = "ui_scale"
        const val K_STATUS = "status_scale"
        const val K_QUICK = "quick_scale"
        // Новый ключ: старый "widget_scale" удалялся как legacy и его нельзя переиспользовать.
        const val K_WIDGET_SCALE = "widget_board_scale"
        const val K_DOCK = "dock_scale"
        const val K_HOTKEY = "hotkey_scale"
        // Ключи panel_scale и weather_city совпадают с прежними версиями — настройки не теряются.
        const val K_PANEL = "panel_scale"
        const val K_ICON = "icon_scale"
        const val K_CLOCK = "clock_scale"
        const val K_CLOCK_STYLE = "clock_style"
        const val K_INTERFACE_FONT = "interface_font"
        const val K_CLOCK_FONT = "clock_font"
        const val K_DATE_FONT = "date_font"
        const val K_GREETING_FONT = "greeting_font"
        const val K_VISUAL_STYLE = "visual_style"
        const val K_WIDGET_STYLE = "widget_style"
        const val K_MUSIC = "music_package"
        const val K_NAV = "nav_package"
        const val K_WEATHER = "weather_package"
        const val K_VIDEO = "video_package"
        const val K_CITY = "weather_city"
        const val K_WEATHER_SOURCE = "weather_source"
        const val K_WP_TYPE = "wallpaper_type"
        const val K_WP_PATH = "wallpaper_path"
        const val K_BOARD1 = "widget_board_page1"
        const val K_BOARD2 = "widget_board_page2"
        const val K_ONBOARDING_DONE = "onboarding_done_v1"
        const val K_CONTRAST = "contrast_strength"
        const val K_TEXT_SIZE = "access_text_size"

        // Удаляемые ключи старой системы виджетов.
        const val K_P1 = "widgets_page1"
        const val K_P2 = "widgets_page2"
        const val K_SIZES = "widget_sizes"
        const val K_WIDGET = "widget_scale"
    }
}
