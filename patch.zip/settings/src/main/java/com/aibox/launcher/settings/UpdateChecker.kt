package com.aibox.launcher.settings

import android.app.DownloadManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.FileInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

data class UpdateInfo(
    val tag: String,
    val build: Int,
    val title: String,
    val notes: String,
    val apkUrl: String,
    val versionName: String = "",
    val sha256: String = "",
    val size: Long = 0L,
    val minSdk: Int = 0,
    val signatureSha256: String = "",
    val channel: String = "",
    /** Полный versionCode из манифеста; `build` — его int-представление для старого UI. */
    val versionCode: Long = build.toLong(),
    /** true, если данные получены из update-manifest.json (есть sha256). */
    val fromManifest: Boolean = false
)

class NoReleasesException(message: String = "Релизов пока нет") : Exception(message)

/**
 * Проверка и установка обновлений из GitHub Releases.
 *
 * При наличии ассета update-manifest.json используются его versionCode/sha256/подпись,
 * иначе — старый формат релиза `build-N` с первым попавшимся APK.
 */
object UpdateChecker {
    // В SDK-стабах константа отсутствует, но на устройстве действие существует с API 21.
    private const val ACTION_INSTALL_COMMIT = "android.content.pm.action.COMMIT_INSTALL"

    @Volatile
    private var appContext: Context? = null

    // ------------------------------------------------------------------ Публичный API

    /** Совместимый вызов; для корректного выбора channel лучше fetchLatest(context). */
    suspend fun fetchLatest(): Result<UpdateInfo> = fetchLatest(currentContext())

    suspend fun fetchLatest(context: Context?): Result<UpdateInfo> = withContext(Dispatchers.IO) {
        runCatching {
            val ctx = context?.let { remember(it) } ?: currentContext()
            val release = JSONObject(fetchText("https://api.github.com/repos/$UPDATE_REPO/releases/latest"))
            val releaseTag = release.optString("tag_name").trim()
            val assets = assetMap(release)
            val channel = channelFor((ctx?.packageName ?: inferApplicationId()).orEmpty())
            val title = release.optString("name").ifBlank { releaseTag }

            val info = if (assets.keys.any { it.equals(UPDATE_MANIFEST_NAME, ignoreCase = true) }) {
                val manifestUrl = assets.entries.first {
                    it.key.equals(UPDATE_MANIFEST_NAME, ignoreCase = true)
                }.value
                val manifest = UpdateManifest.parse(fetchText(manifestUrl))
                val tag = manifest.tag.ifBlank { releaseTag }
                val variant = manifest.select(channel)
                    ?: throw SecurityException("В манифесте обновления нет APK для сборки $channel")
                // apkRef из apks[].fileName ищется среди ассетов релиза по имени.
                val apkUrl = resolveApkUrl(variant.apkRef, assets)
                    ?: throw NoReleasesException("В релизе нет APK ${variant.apkRef}")
                requireHttps(apkUrl)
                UpdateInfo(
                    tag = tag.ifBlank { "build-${variant.versionCode}" },
                    build = buildInt(variant.versionCode),
                    title = title,
                    notes = release.optString("body").ifBlank { "" },
                    apkUrl = apkUrl,
                    versionName = variant.versionName.ifBlank { manifest.versionName.ifBlank { tag } },
                    sha256 = variant.sha256,
                    size = variant.size,
                    minSdk = if (variant.minSdk > 0) variant.minSdk else manifest.minSdk,
                    signatureSha256 = variant.signatureSha256,
                    channel = variant.channel.ifBlank { channel },
                    versionCode = variant.versionCode,
                    fromManifest = true
                )
            } else {
                // Совместимость с уже опубликованными релизами без манифеста.
                val apk = assets.entries.firstOrNull {
                    it.key.contains(channel, ignoreCase = true) && it.key.endsWith(".apk", ignoreCase = true)
                } ?: assets.entries.firstOrNull { it.key.endsWith(".apk", ignoreCase = true) }
                ?: throw NoReleasesException("В релизе нет APK для обновления")
                requireHttps(apk.value)
                val build = Regex("(\\d+)$").find(releaseTag)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                UpdateInfo(
                    tag = releaseTag,
                    build = build,
                    title = title,
                    notes = release.optString("body").ifBlank { "" },
                    apkUrl = apk.value,
                    versionName = releaseTag,
                    versionCode = build.toLong()
                )
            }

            //Без Context часть проверок выполняется уже в downloadAndInstall().
            if (ctx != null) {
                updateBlockReason(ctx, info)?.let { throw SecurityException(it) }
            }
            info
        }
    }

    /** Текст ошибки для UI, если он показывает причину отказа отдельно от Toast. */
    fun describeError(error: Throwable): String = when (error) {
        is NoReleasesException -> error.message ?: "Релизов пока нет"
        is SecurityException -> error.message ?: "Обновление отклонено по соображениям безопасности"
        is IllegalArgumentException -> error.message ?: "Некорректный манифест обновления"
        else -> error.message?.takeIf { it.isNotBlank() } ?: "Не удалось проверить: нет связи с GitHub"
    }

    /**
     * Причина, по которой обновление нельзя ставить, или null, если всё в порядке.
     * Используется и при проверке, и перед скачиванием.
     */
    fun updateBlockReason(context: Context, info: UpdateInfo): String? {
        val ctx = remember(context)
        val current = currentBuild(ctx)
        if (current > 0 && info.versionCode in 1..current) {
            return "Установлена версия не ниже предлагаемой"
        }
        if (info.minSdk > Build.VERSION.SDK_INT) {
            return "Обновление требует Android ${info.minSdk} или новее"
        }
        val expected = normalizeDigest(info.signatureSha256)
        if (expected.isNotBlank()) {
            if (!isSha256(expected)) return "Некорректная подпись в манифесте обновления"
            val actual = installedSignatureHashes(ctx)
            if (actual.isEmpty()) return "Не удалось проверить подпись установленного приложения"
            if (expected !in actual) {
                return "Подпись обновления не совпадает с подписью установленного приложения"
            }
        }
        return null
    }

    fun currentBuild(context: Context): Long {
        val ctx = remember(context)
        return runCatching {
            @Suppress("DEPRECATION")
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode
        }.getOrDefault(0L)
    }

    fun hasInstallPermission(context: Context): Boolean = remember(context)
        .packageManager.canRequestPackageInstalls()

    fun openInstallPermissionSettings(context: Context) {
        val app = remember(context)
        val uri = Uri.parse("package:${app.packageName}")
        val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, uri)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            app.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            val details = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { app.startActivity(details) }
        }
    }

    /** Продолжение после возврата из системных настроек установки неизвестных источников. */
    fun continueAfterPermission(context: Context, info: UpdateInfo): Boolean {
        remember(context)
        if (!hasInstallPermission(context)) {
            toast(context, "Разрешите установку приложений из этого источника и повторите")
            return false
        }
        return downloadAndInstall(context, info)
    }

    /**
     * true — загрузка поставлена в очередь; результат установки приходит в Toast
     * из BroadcastReceiver. false — обновление отклонено до скачивания.
     */
    fun downloadAndInstall(context: Context, info: UpdateInfo): Boolean {
        val app = remember(context)
        val reason = updateBlockReason(app, info)
        if (reason != null) {
            toast(app, reason)
            return false
        }
        if (!hasInstallPermission(app)) {
            toast(app, "Разрешите установку приложений из этого источника и повторите")
            return false
        }
        val manager = app.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
        if (manager == null) {
            toast(app, "Загрузчик недоступен на устройстве")
            return false
        }
        if (!info.apkUrl.startsWith("https://", ignoreCase = true)) {
            toast(app, "Некорректная ссылка на обновление")
            return false
        }

        val label = safeName(info.versionName.ifBlank { info.tag })
        val fileName = "aibox-update-$label-${System.currentTimeMillis()}-${
            UUID.randomUUID().toString().take(8)
        }.apk"
        val request = DownloadManager.Request(Uri.parse(info.apkUrl))
            .setTitle("AI Box Launcher ${info.versionName.ifBlank { info.tag }}")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(app, Environment.DIRECTORY_DOWNLOADS, fileName)

        val downloadId = try {
            manager.enqueue(request)
        } catch (_: Throwable) {
            toast(app, "Не удалось начать загрузку обновления")
            return false
        }

        val handled = AtomicBoolean(false)
        lateinit var receiver: BroadcastReceiver
        receiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context, intent: Intent) {
                if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) != downloadId) return
                handleDownload(app, manager, downloadId, info, receiver, handled)
            }
        }
        ContextCompat.registerReceiver(
            app,
            receiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        // Broadcast мог прийти до регистрации receiver — проверяем состояние сразу.
        if (queryStatus(manager, downloadId) == DownloadManager.STATUS_SUCCESSFUL ||
            queryStatus(manager, downloadId) == DownloadManager.STATUS_FAILED
        ) {
            handleDownload(app, manager, downloadId, info, receiver, handled)
        }
        toast(app, "Загрузка обновления началась")
        return true
    }

    // ------------------------------------------------------------------ Загрузка и установка

    private fun handleDownload(
        app: Context,
        manager: DownloadManager,
        downloadId: Long,
        info: UpdateInfo,
        receiver: BroadcastReceiver,
        handled: AtomicBoolean
    ) {
        if (!handled.compareAndSet(false, true)) return
        runCatching { app.unregisterReceiver(receiver) }

        when (queryStatus(manager, downloadId)) {
            DownloadManager.STATUS_FAILED -> {
                toast(app, "Не удалось скачать обновление: ${downloadError(manager, downloadId)}")
                return
            }
            DownloadManager.STATUS_SUCCESSFUL -> Unit
            else -> {
                toast(app, "Загрузка обновления не завершена")
                return
            }
        }

        val uri = runCatching { manager.getUriForDownloadedFile(downloadId) }.getOrNull()
        if (uri == null) {
            toast(app, "Не удалось скачать обновление")
            return
        }

        if (info.sha256.isNotBlank()) {
            if (!isSha256(info.sha256)) {
                toast(app, "Некорректная контрольная сумма в манифесте — установка отменена")
                return
            }
            val actual = hashDownload(manager, downloadId)
            if (actual == null) {
                toast(app, "Не удалось прочитать скачанный файл")
                return
            }
            if (!actual.equals(normalizeDigest(info.sha256), ignoreCase = true)) {
                toast(app, "Контрольная сумма обновления не совпала — установка отменена")
                return
            }
        }

        try {
            installWithPackageInstaller(app, manager, downloadId)
        } catch (_: Throwable) {
            // PackageInstaller недоступен — старый путь через системный установщик.
            openSystemInstaller(app, uri)
        }
    }

    private fun installWithPackageInstaller(
        app: Context,
        manager: DownloadManager,
        downloadId: Long
    ) {
        val installer = app.packageManager.packageInstaller
        val sessionId = installer.createSession(
            PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        )
        val session = installer.openSession(sessionId)
        val receiver = installReceiver(app, sessionId)
        ContextCompat.registerReceiver(
            app,
            receiver,
            IntentFilter(ACTION_INSTALL_COMMIT),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        var committed = false
        try {
            session.use { s ->
                val writeStream = s.openWrite("aibox-update.apk", 0, -1)
                writeStream.use { out ->
                    val input = FileInputStream(manager.openDownloadedFile(downloadId).fileDescriptor)
                        ?: throw IOException("Нет доступа к скачанному APK")
                    input.use { it.copyTo(out) }
                    out.flush()
                    s.fsync(out)
                }
                // ACTION + package сужают доставку ответа именно нашей сессии.
                val pending = PendingIntent.getBroadcast(
                    app,
                    sessionId.toInt(),
                    Intent(ACTION_INSTALL_COMMIT).setPackage(app.packageName),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                s.commit(pending.intentSender)
                committed = true
            }
        } catch (t: Throwable) {
            if (!committed) {
                runCatching { app.unregisterReceiver(receiver) }
                runCatching { installer.abandonSession(sessionId) }
            }
            throw t
        }
    }

    private fun installReceiver(app: Context, sessionId: Int): BroadcastReceiver =
        object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action != ACTION_INSTALL_COMMIT) return
                val packageName = intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME)
                if (!packageName.isNullOrBlank() && packageName != app.packageName) return
                val reportedSession = intent.getLongExtra(PackageInstaller.EXTRA_SESSION_ID, -1L)
                if (reportedSession != -1L && reportedSession != sessionId.toLong()) return

                runCatching { app.unregisterReceiver(this) }
                when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
                    PackageInstaller.STATUS_SUCCESS -> toast(app, "Обновление установлено")
                    PackageInstaller.STATUS_FAILURE_ABORTED -> toast(app, "Установка обновления отменена")
                    else -> {
                        val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
                            ?.takeIf { it.isNotBlank() }
                            ?: "ошибка установщика"
                        toast(app, "Не удалось установить обновление: $message")
                    }
                }
            }
        }

    private fun openSystemInstaller(app: Context, uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            app.startActivity(intent)
            toast(app, "Продолжите установку в системном установщике")
        } catch (_: Throwable) {
            toast(app, "Не удалось открыть установщик")
        }
    }

    private fun hashDownload(manager: DownloadManager, downloadId: Long): String? {
        val stream = try {
            FileInputStream(manager.openDownloadedFile(downloadId).fileDescriptor)
        } catch (_: Throwable) {
            null
        } ?: return null
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        stream.use { input ->
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().toDigestString()
    }

    private fun queryStatus(manager: DownloadManager, downloadId: Long): Int =
        queryColumn(manager, downloadId, DownloadManager.COLUMN_STATUS)

    private fun downloadError(manager: DownloadManager, downloadId: Long): String =
        when (queryColumn(manager, downloadId, DownloadManager.COLUMN_REASON)) {
            DownloadManager.ERROR_CANNOT_RESUME -> "загрузку нельзя продолжить"
            DownloadManager.ERROR_DEVICE_NOT_FOUND -> "устройство хранения недоступно"
            DownloadManager.ERROR_FILE_ERROR -> "файл не найден или повреждён"
            DownloadManager.ERROR_INSUFFICIENT_SPACE -> "недостаточно места"
            DownloadManager.ERROR_HTTP_DATA_ERROR -> "ошибка HTTP-загрузки"
            DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "слишком много перенаправлений"
            DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "неподдерживаемый ответ сервера"
            else -> "неизвестная ошибка загрузки"
        }

    private fun queryColumn(manager: DownloadManager, downloadId: Long, column: String): Int {
        val cursor = try {
            manager.query(DownloadManager.Query().setFilterById(downloadId))
        } catch (_: Throwable) {
            null
        } ?: return -1
        return cursor.use { c ->
            if (!c.moveToFirst()) return@use -1
            val index = c.getColumnIndex(column)
            if (index < 0) -1 else c.getInt(index)
        }
    }

    // ------------------------------------------------------------------ Вспомогательное

    private fun fetchText(url: String): String {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 8_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("User-Agent", "aibox-launcher")
            when (val code = connection.responseCode) {
                404 -> throw NoReleasesException()
                !in 200..299 -> throw IllegalStateException("HTTP $code")
            }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun assetMap(release: JSONObject): Map<String, String> {
        val assets = release.optJSONArray("assets") ?: return emptyMap()
        val result = LinkedHashMap<String, String>()
        for (i in 0 until assets.length()) {
            val asset = assets.optJSONObject(i) ?: continue
            val name = asset.optString("name").trim()
            val url = asset.optString("browser_download_url").trim()
            if (name.isNotBlank() && url.isNotBlank()) result[name] = url
        }
        return result
    }

    private fun resolveApkUrl(ref: String, assets: Map<String, String>): String? {
        val value = ref.trim()
        if (value.startsWith("https://", ignoreCase = true)) return value
        assets.entries.firstOrNull {
            it.key.equals(value, ignoreCase = true) || it.key.endsWith("/$value", ignoreCase = true)
        }?.let { return it.value }
        return assets.entries.firstOrNull { it.key.endsWith(".apk", ignoreCase = true) }?.value
    }

    private fun requireHttps(url: String) {
        if (!url.startsWith("https://", ignoreCase = true)) {
            throw SecurityException("Ссылка на обновление должна использовать HTTPS")
        }
    }

    private fun channelFor(applicationId: String): String = when {
        applicationId == "com.aibox.launcher.debug" || applicationId.endsWith(".debug") -> "debug"
        else -> "release"
    }

    private fun inferApplicationId(): String? = runCatching {
        Class.forName("android.app.ActivityThread")
            .getMethod("currentApplication")
            .invoke(null) as? Context
    }.getOrNull()?.let { remember(it).packageName }

    private fun installedSignatureHashes(context: Context): Set<String> {
        val info = try {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(
                context.packageName,
                PackageManager.GET_SIGNING_CERTIFICATES
            )
        } catch (_: Throwable) {
            return emptySet()
        }
        val signingInfo = info.signingInfo ?: return emptySet()
        val signatures = mutableListOf<android.content.pm.Signature>()
        signingInfo.apkContentsSigners?.let { signatures.addAll(it.toList()) }
        signingInfo.signingCertificateHistory?.let { signatures.addAll(it.toList()) }
        return signatures.mapNotNull { signature ->
            runCatching {
                MessageDigest.getInstance("SHA-256").digest(signature.toByteArray()).toDigestString()
            }.getOrNull()
        }.toSet()
    }

    private fun buildInt(versionCode: Long): Int = when {
        versionCode > Int.MAX_VALUE -> Int.MAX_VALUE
        versionCode < Int.MIN_VALUE -> Int.MIN_VALUE
        else -> versionCode.toInt()
    }

    private fun safeName(value: String): String =
        value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(40)

    private fun ByteArray.toDigestString(): String {
        val digits = "0123456789abcdef"
        val out = StringBuilder(size * 2)
        for (byte in this) {
            val value = byte.toInt() and 0xff
            out.append(digits[value ushr 4]).append(digits[value and 0x0f])
        }
        return out.toString()
    }

    private fun remember(context: Context): Context {
        val app = context.applicationContext
        appContext = app
        return app
    }

    private fun currentContext(): Context? = appContext ?: runCatching {
        Class.forName("android.app.ActivityThread")
            .getMethod("currentApplication")
            .invoke(null) as? Context
    }.getOrNull()?.let { remember(it) }

    private fun toast(context: Context, message: String) {
        Toast.makeText(context.applicationContext, message, Toast.LENGTH_LONG).show()
    }
}
