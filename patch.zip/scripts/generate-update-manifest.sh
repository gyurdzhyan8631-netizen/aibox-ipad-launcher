#!/usr/bin/env bash
# Генерирует update-manifest.json и SHA256SUMS для GitHub Release.
# Использование:
#   scripts/generate-update-manifest.sh <debug.apk> <release.apk> <versionCode> <versionName> <tag>
# По умолчанию файлы пишутся в корень репозитория; OUT_DIR может переопределить путь.
set -euo pipefail

usage() {
  echo "Usage: $0 <debug.apk> <release.apk> <versionCode> <versionName> <tag>" >&2
}

if [ "$#" -ne 5 ]; then
  usage
  exit 2
fi

DEBUG_APK=$1
RELEASE_APK=$2
VERSION_CODE=$3
VERSION_NAME=$4
TAG=$5

for apk in "$DEBUG_APK" "$RELEASE_APK"; do
  if [ ! -f "$apk" ]; then
    echo "APK not found: $apk" >&2
    exit 1
  fi
done
if ! [[ "$VERSION_CODE" =~ ^[0-9]+$ ]]; then
  echo "versionCode must be a number: $VERSION_CODE" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT_DIR="${OUT_DIR:-$(cd "$SCRIPT_DIR/.." && pwd)}"
mkdir -p "$OUT_DIR"

sha256_of() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  else
    echo "Neither sha256sum nor shasum is available" >&2
    exit 1
  fi
}

size_of() {
  if stat -c '%s' "$1" >/dev/null 2>&1; then
    stat -c '%s' "$1"
  else
    stat -f '%z' "$1"
  fi
}

# keytool печатает отпечаток как "SHA256: AA:BB:...". Возвращаем 64 символа
# без двоеточий в верхнем регистре, чтобы сравнить с отпечатком сертификата в Android.
# Если keytool отсутствует — возвращаем пустую строку: проверка подписи пропускается.
signature_sha256_of() {
  if ! command -v keytool >/dev/null 2>&1; then
    printf ''
    return
  fi
  local raw
  raw="$(LC_ALL=C keytool -printcert -jarfile "$1" 2>/dev/null \
    | LC_ALL=C awk '/^[[:space:]]*SHA256:/ { print $2; exit }' \
    | tr -d '\r' || true)"
  if ! [[ "$raw" =~ ^[0-9A-Fa-f:]+$ ]]; then
    raw=""
  fi
  printf '%s' "${raw//:/}" | LC_ALL=C tr '[:lower:]' '[:upper:]'
}

json_escape() {
  local s=$1
  s=${s//\\/\\\\}
  s=${s//\"/\\\"}
  s=${s//$'\n'/\\n}
  s=${s//$'\r'/\\r}
  s=${s//$'\t'/\\t}
  printf '%s' "$s"
}

DEBUG_NAME=$(basename "$DEBUG_APK")
RELEASE_NAME=$(basename "$RELEASE_APK")
DEBUG_SHA256=$(sha256_of "$DEBUG_APK")
RELEASE_SHA256=$(sha256_of "$RELEASE_APK")
DEBUG_SIZE=$(size_of "$DEBUG_APK")
RELEASE_SIZE=$(size_of "$RELEASE_APK")
DEBUG_SIGNATURE=$(signature_sha256_of "$DEBUG_APK")
RELEASE_SIGNATURE=$(signature_sha256_of "$RELEASE_APK")

{
  printf '{\n'
  printf '  "versionCode": %s,\n' "$VERSION_CODE"
  printf '  "versionName": "%s",\n' "$(json_escape "$VERSION_NAME")"
  printf '  "tag": "%s",\n' "$(json_escape "$TAG")"
  printf '  "minSdk": 31,\n'
  printf '  "apks": [\n'
  printf '    {\n'
  printf '      "channel": "debug",\n'
  printf '      "fileName": "%s",\n' "$(json_escape "$DEBUG_NAME")"
  printf '      "sha256": "%s",\n' "$DEBUG_SHA256"
  printf '      "size": %s,\n' "$DEBUG_SIZE"
  printf '      "signatureSha256": "%s"\n' "$DEBUG_SIGNATURE"
  printf '    },\n'
  printf '    {\n'
  printf '      "channel": "release",\n'
  printf '      "fileName": "%s",\n' "$(json_escape "$RELEASE_NAME")"
  printf '      "sha256": "%s",\n' "$RELEASE_SHA256"
  printf '      "size": %s,\n' "$RELEASE_SIZE"
  printf '      "signatureSha256": "%s"\n' "$RELEASE_SIGNATURE"
  printf '    }\n'
  printf '  ]\n'
  printf '}\n'
} > "$OUT_DIR/update-manifest.json"

printf '%s  %s\n%s  %s\n' \
  "$DEBUG_SHA256" "$DEBUG_NAME" \
  "$RELEASE_SHA256" "$RELEASE_NAME" > "$OUT_DIR/SHA256SUMS"

echo "Wrote $OUT_DIR/update-manifest.json and $OUT_DIR/SHA256SUMS"
